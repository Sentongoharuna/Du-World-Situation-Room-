package com.sentongoharuna.worldsituationroom;

import android.content.Context;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Immutable, source-attributed widget view of the app's last acquired records. */
public final class WidgetSnapshot {
    public enum Tone { RED, AMBER, GREEN, CYAN, GRAY }

    private final EnumMap<Signal.Layer, List<Signal>> layers =
            new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, FeedStatus> statuses =
            new EnumMap<>(Signal.Layer.class);
    public final long assembledAtMs;
    public final long lastSourceUpdateMs;
    public final int onlineFeeds;
    public final int cachedFeeds;
    public final int offlineFeeds;
    public final int optionalFeeds;

    private WidgetSnapshot(Context context) {
        assembledAtMs = System.currentTimeMillis();
        OperationsSnapshotStore store = new OperationsSnapshotStore(context);
        EnumMap<Signal.Layer, OperationsSnapshotStore.Snapshot> restored = store.loadAll();
        store.shutdown();
        WidgetStateStore stateStore = new WidgetStateStore(context);
        statuses.putAll(stateStore.loadStatuses());
        long last = stateStore.lastAnyUpdate();
        for (Signal.Layer layer : Signal.Layer.values()) {
            OperationsSnapshotStore.Snapshot snapshot = restored.get(layer);
            if (snapshot == null) {
                layers.put(layer, Collections.emptyList());
            } else {
                layers.put(layer, snapshot.signals);
                if (!statuses.containsKey(layer)) statuses.put(layer, snapshot.status);
                last = Math.max(last, snapshot.savedAtMs);
            }
            FeedStatus status = statuses.get(layer);
            if (status != null) last = Math.max(last, status.updatedAtMs);
        }
        lastSourceUpdateMs = last;
        int online = 0;
        int cached = 0;
        int offline = 0;
        int optional = 0;
        for (Signal.Layer layer : Signal.Layer.values()) {
            FeedStatus status = effectiveStatus(layer);
            if (status == null) continue;
            switch (status.state) {
                case LIVE:
                case READY: online++; break;
                case CACHED:
                case DELAYED: cached++; break;
                case KEY_REQUIRED: optional++; break;
                case OFFLINE: offline++; break;
                default: break;
            }
        }
        onlineFeeds = online;
        cachedFeeds = cached;
        offlineFeeds = offline;
        optionalFeeds = optional;
    }

    public static WidgetSnapshot load(Context context) {
        return new WidgetSnapshot(context.getApplicationContext());
    }

    public List<Signal> records(Signal.Layer layer, DuWidgetPreferences.Config config) {
        List<Signal> source = layers.get(layer);
        if (source == null || source.isEmpty()) return Collections.emptyList();
        List<Signal> result = new ArrayList<>();
        for (Signal signal : source) {
            if (isEventLayer(layer) && signal.severity < config.minimumSeverity) continue;
            if (matchesWatch(signal, config)) result.add(signal);
        }
        sortNewestFirst(result);
        return result;
    }

    public List<Signal> events(DuWidgetPreferences.Config config) {
        List<Signal> result = new ArrayList<>();
        for (Signal.Layer layer : new Signal.Layer[]{Signal.Layer.NEWS,
                Signal.Layer.NATURAL, Signal.Layer.AIRSPACE, Signal.Layer.SPACE_WEATHER}) {
            result.addAll(records(layer, config));
        }
        sortNewestFirst(result);
        return result;
    }

    public List<Signal> priorityEvents(DuWidgetPreferences.Config config) {
        List<Signal> result = new ArrayList<>();
        for (Signal signal : events(config)) if (signal.severity >= 4) result.add(signal);
        return result;
    }

    public List<Signal> combined(DuWidgetPreferences.Config config,
                                 Signal.Layer... requested) {
        List<Signal> result = new ArrayList<>();
        for (Signal.Layer layer : requested) result.addAll(records(layer, config));
        sortNewestFirst(result);
        return result;
    }

    public List<Signal> globeRecords(DuWidgetPreferences.Config config) {
        List<Signal> values = combined(config, Signal.Layer.FLIGHTS, Signal.Layer.SHIPS,
                Signal.Layer.NATURAL, Signal.Layer.NEWS, Signal.Layer.AIRSPACE,
                Signal.Layer.SATELLITES);
        List<Signal> result = new ArrayList<>();
        int moving = 0;
        int events = 0;
        for (Signal signal : values) {
            if (!signal.hasLocation()) continue;
            boolean event = isEventLayer(signal.layer);
            if (event && events++ >= 90) continue;
            if (!event && moving++ >= 170) continue;
            result.add(signal);
            if (result.size() >= 230) break;
        }
        return result;
    }

    public Signal atCursor(List<Signal> values, int cursor) {
        return values == null || values.isEmpty()
                ? null : values.get(Math.floorMod(cursor, values.size()));
    }

    public int count(Signal.Layer layer) {
        FeedStatus status = effectiveStatus(layer);
        List<Signal> values = layers.get(layer);
        return Math.max(status == null ? 0 : status.count,
                values == null ? 0 : values.size());
    }

    public FeedStatus effectiveStatus(Signal.Layer layer) {
        FeedStatus status = statuses.get(layer);
        if (status == null) return null;
        long maximumAge = freshnessBudgetMs(layer);
        if ((status.state == FeedStatus.State.LIVE || status.state == FeedStatus.State.READY)
                && status.updatedAtMs > 0L
                && assembledAtMs - status.updatedAtMs > maximumAge) {
            return new FeedStatus(FeedStatus.State.DELAYED, status.count,
                    "Last successful source state exceeded its freshness budget",
                    status.updatedAtMs);
        }
        return status;
    }

    public String healthBadge() {
        if (lastSourceUpdateMs <= 0L) return "WAITING";
        if (onlineFeeds > 0 && assembledAtMs - lastSourceUpdateMs <= 20L * 60L * 1000L) {
            return "LIVE/CACHED";
        }
        if (cachedFeeds > 0 || onlineFeeds > 0) return "DELAYED";
        return offlineFeeds > 0 ? "OFFLINE" : "CACHED";
    }

    public Tone healthTone() {
        if (lastSourceUpdateMs <= 0L) return Tone.GRAY;
        if (offlineFeeds > 0 && onlineFeeds == 0 && cachedFeeds == 0) return Tone.RED;
        if (assembledAtMs - lastSourceUpdateMs > 30L * 60L * 1000L) return Tone.AMBER;
        return onlineFeeds > 0 ? Tone.GREEN : Tone.AMBER;
    }

    public String sourceHealthLine() {
        return String.format(Locale.US, "READY %d • CACHED %d • OFFLINE %d • OPTIONAL %d",
                onlineFeeds, cachedFeeds, offlineFeeds, optionalFeeds);
    }

    public static String credibility(Signal signal) {
        if (signal == null || signal.credibility == null) return "NO SIGNAL";
        return signal.credibility.name().replace('_', ' ');
    }

    public static String ageText(long timestampMs, long nowMs) {
        if (timestampMs <= 0L) return "NO TIMESTAMP";
        long seconds = Math.max(0L, (nowMs - timestampMs) / 1000L);
        if (seconds < 60L) return seconds + "s AGO";
        long minutes = seconds / 60L;
        if (minutes < 60L) return minutes + "m AGO";
        long hours = minutes / 60L;
        if (hours < 48L) return hours + "h AGO";
        return hours / 24L + "d AGO";
    }

    public static String compact(String value, int maximum) {
        String clean = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        if (clean.length() <= maximum) return clean;
        return clean.substring(0, Math.max(1, maximum - 1)) + "…";
    }

    public static String fact(Signal signal, String... keys) {
        if (signal != null) {
            for (String requested : keys) {
                for (Map.Entry<String, String> fact : signal.facts.entrySet()) {
                    if (fact.getKey().equalsIgnoreCase(requested)
                            && fact.getValue() != null && !fact.getValue().trim().isEmpty()) {
                        return fact.getValue().trim();
                    }
                }
            }
        }
        return "NOT REPORTED";
    }

    public static String sources(List<Signal> values, int maximum) {
        Set<String> result = new LinkedHashSet<>();
        if (values != null) {
            for (Signal signal : values) {
                if (signal.source != null && !signal.source.trim().isEmpty()) result.add(signal.source);
                if (result.size() >= maximum) break;
            }
        }
        if (result.isEmpty()) return "NO ACQUIRED SOURCE";
        StringBuilder joined = new StringBuilder();
        for (String source : result) {
            if (joined.length() > 0) joined.append(" • ");
            joined.append(source);
        }
        return joined.toString();
    }

    private boolean matchesWatch(Signal signal, DuWidgetPreferences.Config config) {
        if (signal == null) return false;
        if (config.radiusKm > 0 && signal.hasLocation()) {
            return distanceKm(config.latitude, config.longitude,
                    signal.latitude, signal.longitude) <= config.radiusKm;
        }
        String configured = config.region == null ? "GLOBAL" : config.region.toUpperCase(Locale.ROOT);
        if ("GLOBAL".equals(configured)) return true;
        if ("AUTO REGION".equals(configured)) {
            configured = RegionalFocus.detect().worldRegion;
        }
        return "GLOBAL".equals(signal.region)
                || signal.region.contains(configured)
                || configured.contains(signal.region);
    }

    private static boolean isEventLayer(Signal.Layer layer) {
        return layer == Signal.Layer.NEWS || layer == Signal.Layer.NATURAL
                || layer == Signal.Layer.AIRSPACE || layer == Signal.Layer.SPACE_WEATHER;
    }

    private static long freshnessBudgetMs(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return 5L * 60L * 1000L;
            case SHIPS: return 20L * 60L * 1000L;
            case WEATHER: return 30L * 60L * 1000L;
            case NEWS: return 15L * 60L * 1000L;
            case AIRSPACE: return 30L * 60L * 1000L;
            case SATELLITES: return 3L * 60L * 60L * 1000L;
            default: return 2L * 60L * 60L * 1000L;
        }
    }

    /** Collections.sort is available on every supported API level; List.sort is API 24+. */
    private static void sortNewestFirst(List<Signal> values) {
        Collections.sort(values, (first, second) -> {
            if (first.timestampMs == second.timestampMs) return 0;
            return first.timestampMs < second.timestampMs ? 1 : -1;
        });
    }

    private static double distanceKm(double lat1, double lon1, double lat2, double lon2) {
        double p1 = Math.toRadians(lat1);
        double p2 = Math.toRadians(lat2);
        double dLat = p2 - p1;
        double dLon = Math.toRadians(lon2 - lon1);
        double value = Math.sin(dLat / 2d) * Math.sin(dLat / 2d)
                + Math.cos(p1) * Math.cos(p2)
                * Math.sin(dLon / 2d) * Math.sin(dLon / 2d);
        return 6371d * 2d * Math.atan2(Math.sqrt(value), Math.sqrt(1d - value));
    }
}
