package com.sentongoharuna.worldsituationroom;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;
import android.content.SharedPreferences;

/** Per-instance watch profile. Multiple copies of one widget can watch different regions. */
public final class DuWidgetPreferences {
    public static final String[] REGIONS = {
            "AUTO REGION", "GLOBAL", "AFRICA", "MIDDLE EAST", "EUROPE",
            "ASIA", "AMERICAS", "OCEANIA"
    };
    public static final int[] RADII_KM = {0, 250, 750, 1500, 3000};
    public static final String[] RADIUS_LABELS = {
            "REGION / WORLD", "250 KM", "750 KM", "1,500 KM", "3,000 KM"
    };

    public static final class Config {
        public final int widgetId;
        public final DuWidgetContract.Kind kind;
        public final String label;
        public final String region;
        public final int minimumSeverity;
        public final int radiusKm;
        public final boolean showSources;
        public final boolean backgroundRefresh;
        public final double latitude;
        public final double longitude;
        public final int cursor;

        Config(int widgetId, DuWidgetContract.Kind kind, String label, String region,
               int minimumSeverity, int radiusKm, boolean showSources,
               boolean backgroundRefresh, double latitude, double longitude, int cursor) {
            this.widgetId = widgetId;
            this.kind = kind;
            this.label = label;
            this.region = region;
            this.minimumSeverity = Math.max(1, Math.min(5, minimumSeverity));
            this.radiusKm = Math.max(0, radiusKm);
            this.showSources = showSources;
            this.backgroundRefresh = backgroundRefresh;
            this.latitude = latitude;
            this.longitude = longitude;
            this.cursor = Math.max(0, cursor);
        }
    }

    private static final String STORE = "du_widget_profiles_v1";
    private final SharedPreferences values;
    private final Context context;

    public DuWidgetPreferences(Context context) {
        this.context = context.getApplicationContext();
        values = this.context.getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }

    public DuWidgetContract.Kind inferKind(int widgetId) {
        AppWidgetProviderInfo info = AppWidgetManager.getInstance(context)
                .getAppWidgetInfo(widgetId);
        return info == null || info.provider == null
                ? DuWidgetContract.Kind.COMMAND
                : DuWidgetContract.fromProviderClassName(info.provider.getClassName());
    }

    public Config load(int widgetId, DuWidgetContract.Kind fallback) {
        RegionalFocus focus = RegionalFocus.detect();
        String prefix = prefix(widgetId);
        DuWidgetContract.Kind kind = fallback;
        String storedKind = SafePreferences.string(values, prefix + "kind", "");
        if (storedKind != null && !storedKind.isEmpty()) {
            try { kind = DuWidgetContract.Kind.valueOf(storedKind); }
            catch (IllegalArgumentException ignored) { kind = fallback; }
        }
        if (kind == null) kind = inferKind(widgetId);
        String defaultRegion = kind == DuWidgetContract.Kind.LOCAL
                ? "AUTO REGION" : "GLOBAL";
        int defaultRadius = kind == DuWidgetContract.Kind.LOCAL ? 1500 : 0;
        return new Config(widgetId, kind,
                SafePreferences.string(values, prefix + "label", focus.name),
                SafePreferences.string(values, prefix + "region", defaultRegion),
                SafePreferences.integer(values, prefix + "severity", 1),
                SafePreferences.integer(values, prefix + "radius", defaultRadius),
                SafePreferences.bool(values, prefix + "sources", true),
                SafePreferences.bool(values, prefix + "background", true),
                Double.longBitsToDouble(SafePreferences.longValue(values, prefix + "latitude",
                        Double.doubleToRawLongBits(focus.latitude))),
                Double.longBitsToDouble(SafePreferences.longValue(values, prefix + "longitude",
                        Double.doubleToRawLongBits(focus.longitude))),
                SafePreferences.integer(values, prefix + "cursor", 0));
    }

    public void save(Config config) {
        String prefix = prefix(config.widgetId);
        values.edit()
                .putString(prefix + "kind", config.kind.name())
                .putString(prefix + "label", clean(config.label, RegionalFocus.detect().name))
                .putString(prefix + "region", clean(config.region, "GLOBAL"))
                .putInt(prefix + "severity", config.minimumSeverity)
                .putInt(prefix + "radius", config.radiusKm)
                .putBoolean(prefix + "sources", config.showSources)
                .putBoolean(prefix + "background", config.backgroundRefresh)
                .putLong(prefix + "latitude", Double.doubleToRawLongBits(config.latitude))
                .putLong(prefix + "longitude", Double.doubleToRawLongBits(config.longitude))
                .putInt(prefix + "cursor", config.cursor)
                .apply();
    }

    public Config moveCursor(int widgetId, DuWidgetContract.Kind kind, int delta) {
        Config old = load(widgetId, kind);
        int cursor = Math.floorMod(old.cursor + delta, 10_000);
        Config updated = new Config(old.widgetId, old.kind, old.label, old.region,
                old.minimumSeverity, old.radiusKm, old.showSources,
                old.backgroundRefresh, old.latitude, old.longitude, cursor);
        save(updated);
        return updated;
    }

    public void delete(int widgetId) {
        String prefix = prefix(widgetId);
        SharedPreferences.Editor edit = values.edit();
        for (String key : values.getAll().keySet()) {
            if (key.startsWith(prefix)) edit.remove(key);
        }
        edit.apply();
    }

    private static String prefix(int widgetId) { return "widget_" + widgetId + "_"; }

    private static String clean(String value, String fallback) {
        String result = value == null ? "" : value.trim();
        if (result.isEmpty()) return fallback;
        return result.length() > 40 ? result.substring(0, 40) : result;
    }
}
