package com.sentongoharuna.worldsituationroom;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/** Defensive parser for the official Aviation Weather Center worldwide SIGMET product. */
public final class AviationWarningParser {
    private AviationWarningParser() { }

    public static List<Signal> parse(String body) throws Exception {
        JSONArray values;
        String clean = body == null ? "" : body.trim();
        if (clean.startsWith("[")) {
            values = new JSONArray(clean);
        } else {
            JSONObject root = new JSONObject(clean);
            values = root.optJSONArray("features");
            if (values == null) values = root.optJSONArray("data");
        }
        List<Signal> result = new ArrayList<>();
        if (values == null) return result;
        SimpleDateFormat utc = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US);
        utc.setTimeZone(TimeZone.getTimeZone("UTC"));
        for (int index = 0; index < values.length() && result.size() < 400; index++) {
            JSONObject raw = values.optJSONObject(index);
            if (raw == null) continue;
            JSONObject row = raw.optJSONObject("properties");
            if (row == null) row = raw;
            double[] point = firstPoint(row.optJSONArray("coords"));
            if (point == null) {
                JSONObject geometry = raw.optJSONObject("geometry");
                point = geometry == null ? null
                        : firstPoint(geometry.optJSONArray("coordinates"));
            }
            if (point == null || !valid(point[1], point[0])) continue;

            String id = text(row, "airSigmetId", text(row, "id", String.valueOf(index)));
            String hazard = text(row, "hazard", text(row, "hazardType", "SIGMET"));
            String severityText = text(row, "severity", "");
            String office = text(row, "icaoId", text(row, "firId", "AWC"));
            String rawText = text(row, "rawAirSigmet", text(row, "rawText", ""));
            long from = timestamp(row.opt("validTimeFrom"));
            if (from <= 0L) from = timestamp(row.opt("receiptTime"));
            if (from <= 0L) from = System.currentTimeMillis();
            long until = timestamp(row.opt("validTimeTo"));
            String combined = (hazard + " " + severityText + " " + rawText)
                    .toUpperCase(Locale.ROOT);
            int severity = containsAny(combined, "HURRICANE", "TROPICAL CYCLONE",
                    "VOLCANIC ASH", "SEV TURB", "SEV ICE") ? 4
                    : containsAny(combined, "TURB", "ICE", "CONVECTIVE", "THUNDERSTORM",
                    "DUST", "SAND") ? 3 : 2;

            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("PRODUCT", "Worldwide SIGMET aviation warning");
            facts.put("HAZARD", hazard.isEmpty() ? "Not reported" : hazard);
            facts.put("ISSUING OFFICE", office.isEmpty() ? "Not reported" : office);
            facts.put("VALID FROM", utc.format(new Date(from)));
            facts.put("VALID UNTIL", until > 0L ? utc.format(new Date(until)) : "Not reported");
            String low = text(row, "altitudeLo1", "");
            String high = text(row, "altitudeHi1", "");
            facts.put("ALTITUDE BAND", altitude(low, high));
            facts.put("MAP POSITION", "Representative polygon point; open source for full area");
            facts.put("CREDIBILITY", "Official warning product; conditions can change rapidly");
            result.add(new Signal(
                    "awc-sigmet-" + id,
                    Signal.Layer.AIRSPACE,
                    "SIGMET • " + (hazard.isEmpty() ? "AVIATION HAZARD" : hazard)
                            + (office.isEmpty() ? "" : " • " + office),
                    rawText.isEmpty()
                            ? "Official aviation-weather warning. Open the original source for "
                            + "the full polygon, altitude band and current validity."
                            : limit(rawText, 520),
                    point[1], point[0], Double.NaN,
                    from,
                    "NOAA Aviation Weather Center",
                    "https://aviationweather.gov/gfa/#sigmet",
                    Signal.Credibility.CONFIRMED,
                    "AVIATION WEATHER", regionFor(point[1], point[0]), severity, facts));
        }
        return result;
    }

    private static double[] firstPoint(JSONArray values) {
        if (values == null || values.length() == 0) return null;
        Object first = values.opt(0);
        if (first instanceof JSONObject) {
            JSONObject point = (JSONObject) first;
            double latitude = point.optDouble("lat", point.optDouble("latitude", Double.NaN));
            double longitude = point.optDouble("lon", point.optDouble("longitude", Double.NaN));
            return valid(latitude, longitude) ? new double[]{longitude, latitude} : null;
        }
        if (first instanceof Number && values.length() >= 2
                && values.opt(1) instanceof Number) {
            return new double[]{values.optDouble(0), values.optDouble(1)};
        }
        if (first instanceof JSONArray) return firstPoint((JSONArray) first);
        return null;
    }

    private static long timestamp(Object raw) {
        if (raw instanceof Number) {
            long value = ((Number) raw).longValue();
            return value > 0L && value < 10_000_000_000L ? value * 1_000L : value;
        }
        String value = raw == null ? "" : String.valueOf(raw).trim();
        if (value.matches("[0-9]{9,16}")) {
            try {
                long number = Long.parseLong(value);
                return number < 10_000_000_000L ? number * 1_000L : number;
            } catch (NumberFormatException ignored) {
                return 0L;
            }
        }
        String[] patterns = {
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd HH:mm:ss"
        };
        for (String pattern : patterns) {
            try {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
                format.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date date = format.parse(value);
                if (date != null) return date.getTime();
            } catch (Exception ignored) {
                // Try the next documented/legacy representation.
            }
        }
        return 0L;
    }

    private static String altitude(String low, String high) {
        if ((low == null || low.isEmpty()) && (high == null || high.isEmpty())) {
            return "Not reported";
        }
        String lower = low == null || low.isEmpty() ? "surface" : "FL" + low;
        String upper = high == null || high.isEmpty() ? "unbounded" : "FL" + high;
        return lower + " – " + upper;
    }

    private static String text(JSONObject object, String key, String fallback) {
        String value = object.optString(key, fallback == null ? "" : fallback);
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }

    private static String limit(String value, int maximum) {
        String clean = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        return clean.length() <= maximum ? clean : clean.substring(0, maximum - 1) + "…";
    }

    private static boolean valid(double latitude, double longitude) {
        return !Double.isNaN(latitude) && !Double.isNaN(longitude)
                && latitude >= -90d && latitude <= 90d
                && longitude >= -180d && longitude <= 180d;
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private static String regionFor(double latitude, double longitude) {
        if (latitude < -10d && longitude > 105d) return "OCEANIA";
        if (longitude < -30d) return "AMERICAS";
        if (longitude >= -20d && longitude <= 55d
                && latitude >= -38d && latitude <= 38d) return "AFRICA";
        if (longitude >= -25d && longitude <= 60d && latitude > 38d) return "EUROPE";
        if (longitude >= 25d && longitude <= 65d
                && latitude >= 10d && latitude <= 42d) return "MIDDLE EAST";
        if (longitude > 55d) return "ASIA";
        return "GLOBAL";
    }
}
