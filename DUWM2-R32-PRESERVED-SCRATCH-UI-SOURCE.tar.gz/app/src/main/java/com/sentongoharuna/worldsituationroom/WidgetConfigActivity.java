package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Native configuration surface shared by all widget types and every widget instance. */
public final class WidgetConfigActivity extends Activity {
    private static final int BG = Color.rgb(5, 8, 12);
    private static final int PANEL = Color.rgb(14, 21, 29);
    private static final int TEXT = Color.rgb(235, 241, 244);
    private static final int MUTED = Color.rgb(139, 155, 166);
    private static final int CYAN = Color.rgb(112, 177, 201);
    private static final int GREEN = Color.rgb(75, 166, 124);
    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private DuWidgetContract.Kind kind;
    private DuWidgetPreferences profiles;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setResult(RESULT_CANCELED);
        widgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }
        profiles = new DuWidgetPreferences(this);
        kind = profiles.inferKind(widgetId);
        buildInterface(profiles.load(widgetId, kind));
    }

    private void buildInterface(DuWidgetPreferences.Config current) {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroller.addView(root);

        TextView eyebrow = label("DU WORLD MONITOR / R27 LIVE MOTION WIDGETS", CYAN, 10, true);
        root.addView(eyebrow);
        TextView title = label(kind.title, TEXT, 21, true);
        title.setPadding(0, dp(8), 0, dp(4));
        root.addView(title);
        TextView description = label(kind.description, MUTED, 12, false);
        root.addView(description);
        TextView disclosure = label(
                "WIDGETS SHOW THE LAST ACQUIRED, SOURCE-ATTRIBUTED SNAPSHOT. "
                        + "ANDROID MAY BATCH BACKGROUND REFRESH TO PROTECT BATTERY.",
                MUTED, 9, true);
        disclosure.setPadding(0, dp(10), 0, dp(16));
        root.addView(disclosure);

        EditText watchLabel = new EditText(this);
        watchLabel.setText(current.label);
        watchLabel.setHint("Watch profile label");
        watchLabel.setTextColor(TEXT);
        watchLabel.setHintTextColor(MUTED);
        watchLabel.setSingleLine(true);
        watchLabel.setBackgroundColor(PANEL);
        watchLabel.setPadding(dp(12), 0, dp(12), 0);
        addField(root, "WATCH PROFILE", watchLabel, dp(50));

        Spinner region = spinner(DuWidgetPreferences.REGIONS);
        region.setSelection(indexOf(DuWidgetPreferences.REGIONS, current.region));
        addField(root, "REGION LENS", region, dp(52));

        String[] severities = {
                "1+ / ALL ACQUIRED", "2+ / ELEVATED", "3+ / SIGNIFICANT",
                "4+ / HIGH", "5 / CRITICAL"
        };
        Spinner severity = spinner(severities);
        severity.setSelection(Math.max(0, Math.min(4, current.minimumSeverity - 1)));
        addField(root, "MINIMUM EVENT SEVERITY", severity, dp(52));

        Spinner radius = spinner(DuWidgetPreferences.RADIUS_LABELS);
        radius.setSelection(radiusIndex(current.radiusKm));
        addField(root, "OPTIONAL DISTANCE LENS", radius, dp(52));

        RegionalFocus focus = RegionalFocus.detect();
        TextView inferred = label(String.format(Locale.US,
                "DISTANCE ORIGIN / %s / %.2f°, %.2f° / DEVICE TIMEZONE ONLY — NO GPS",
                focus.name, focus.latitude, focus.longitude), MUTED, 9, true);
        inferred.setPadding(0, dp(6), 0, dp(8));
        root.addView(inferred);

        CheckBox sources = check("Always show source and acquisition age", true);
        sources.setEnabled(false);
        root.addView(sources);
        CheckBox background = check("Allow network-aware background refresh", current.backgroundRefresh);
        root.addView(background);

        TextView cadence = label(
                "CADENCE / IMMEDIATE FROM APP • MANUAL ↻ • APPROX. 15 MINUTES IN BACKGROUND. "
                        + "THE LAUNCHER OR ANDROID MAY DELAY WORK.", MUTED, 9, true);
        cadence.setPadding(0, dp(10), 0, dp(16));
        root.addView(cadence);

        Button save = button("ACTIVATE " + kind.title, GREEN);
        save.setOnClickListener(view -> {
            int selectedRadius = DuWidgetPreferences.RADII_KM[radius.getSelectedItemPosition()];
            DuWidgetPreferences.Config updated = new DuWidgetPreferences.Config(
                    widgetId, kind, watchLabel.getText().toString(),
                    DuWidgetPreferences.REGIONS[region.getSelectedItemPosition()],
                    severity.getSelectedItemPosition() + 1, selectedRadius,
                    true, background.isChecked(),
                    focus.latitude, focus.longitude, current.cursor);
            profiles.save(updated);
            DuWidgetUpdater.showStartingState(this, widgetId, kind);
            DuWidgetUpdater.updateSingle(this, widgetId, kind);
            WidgetRefreshScheduler.schedulePeriodic(this);
            if (background.isChecked()) WidgetRefreshScheduler.scheduleImmediate(this);
            Intent result = new Intent();
            result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
            setResult(RESULT_OK, result);
            Toast.makeText(this, kind.title + " ready", Toast.LENGTH_SHORT).show();
            finish();
        });
        root.addView(save, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        Button cancel = button("CANCEL", CYAN);
        cancel.setOnClickListener(view -> finish());
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        cancelParams.topMargin = dp(8);
        root.addView(cancel, cancelParams);
        setContentView(scroller);
    }

    private void addField(LinearLayout root, String caption, android.view.View view, int height) {
        TextView label = label(caption, CYAN, 9, true);
        label.setPadding(0, dp(10), 0, dp(5));
        root.addView(label);
        root.addView(view, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height));
    }

    private Spinner spinner(String[] values) {
        Spinner result = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        result.setAdapter(adapter);
        result.setBackgroundColor(PANEL);
        return result;
    }

    private CheckBox check(String text, boolean checked) {
        CheckBox result = new CheckBox(this);
        result.setText(text);
        result.setTextColor(TEXT);
        result.setTextSize(11);
        result.setChecked(checked);
        result.setPadding(0, dp(5), 0, dp(5));
        return result;
    }

    private TextView label(String value, int color, int size, boolean bold) {
        TextView result = new TextView(this);
        result.setText(value);
        result.setTextColor(color);
        result.setTextSize(size);
        result.setTypeface(android.graphics.Typeface.MONOSPACE,
                bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        return result;
    }

    private Button button(String value, int color) {
        Button result = new Button(this);
        result.setText(value);
        result.setTextColor(color);
        result.setTextSize(10);
        result.setTypeface(android.graphics.Typeface.MONOSPACE,
                android.graphics.Typeface.BOLD);
        result.setGravity(Gravity.CENTER);
        result.setBackgroundColor(PANEL);
        return result;
    }

    private static int indexOf(String[] values, String requested) {
        for (int index = 0; index < values.length; index++) {
            if (values[index].equalsIgnoreCase(requested)) return index;
        }
        return 0;
    }

    private static int radiusIndex(int value) {
        for (int index = 0; index < DuWidgetPreferences.RADII_KM.length; index++) {
            if (DuWidgetPreferences.RADII_KM[index] == value) return index;
        }
        return 0;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
