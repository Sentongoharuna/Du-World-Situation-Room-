package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Process;
import android.util.Log;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Locale;

/** Local-only crash reference and loop breaker. Nothing in this ledger is uploaded. */
public final class CrashLedger {
    private static final String TAG = "DuCrashLedger";
    private static final String STORE = "du_world_monitor_crash_ledger_v1";
    private static final String LAST_AT = "last_at";
    private static final String LAST_REFERENCE = "last_reference";
    private static final String LAST_COMPONENT = "last_component";
    private static final String LAST_DETAIL = "last_detail";
    private static final String FATAL_COUNT = "fatal_count";
    private static final long LOOP_WINDOW_MS = 10L * 60L * 1000L;
    private static final int MAX_DETAIL = 16_000;

    private CrashLedger() { }

    public static void install(Context context) {
        Context app = context.getApplicationContext();
        Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        if (previous instanceof InstalledHandler) return;
        Thread.setDefaultUncaughtExceptionHandler(new InstalledHandler(app, previous));
    }

    public static String recordRecovered(Context context, String component, Throwable error) {
        return record(context, component, error, false);
    }

    public static String lastReference(Context context) {
        return SafePreferences.string(preferences(context), LAST_REFERENCE, "");
    }

    public static String lastComponent(Context context) {
        return SafePreferences.string(preferences(context), LAST_COMPONENT, "");
    }

    public static boolean hasRecentCrash(Context context) {
        long at = SafePreferences.longValue(preferences(context), LAST_AT, 0L);
        return at > 0L && System.currentTimeMillis() - at <= LOOP_WINDOW_MS;
    }

    public static boolean recentCrashMentions(Context context, String component) {
        if (!hasRecentCrash(context) || component == null || component.isEmpty()) return false;
        String lastComponent = lastComponent(context);
        String detail = SafePreferences.string(preferences(context), LAST_DETAIL, "");
        return lastComponent.contains(component) || detail.contains(component);
    }

    public static boolean shouldUseSafeMode(Context context) {
        SharedPreferences values = preferences(context);
        long at = SafePreferences.longValue(values, LAST_AT, 0L);
        int count = SafePreferences.integer(values, FATAL_COUNT, 0);
        return count >= 2 && at > 0L && System.currentTimeMillis() - at <= LOOP_WINDOW_MS;
    }

    public static void markStable(Context context) {
        preferences(context).edit().putInt(FATAL_COUNT, 0).apply();
    }

    public static void clear(Context context) {
        preferences(context).edit().clear().apply();
    }

    private static String record(
            Context context,
            String component,
            Throwable error,
            boolean fatal) {
        SharedPreferences values = preferences(context);
        long now = System.currentTimeMillis();
        long previousAt = SafePreferences.longValue(values, LAST_AT, 0L);
        int previousCount = SafePreferences.integer(values, FATAL_COUNT, 0);
        int nextCount = fatal && now - previousAt <= LOOP_WINDOW_MS ? previousCount + 1
                : fatal ? 1 : previousCount;
        String detail = stack(error);
        String reference = reference(component, error, now);
        try {
            values.edit()
                    .putLong(LAST_AT, now)
                    .putString(LAST_REFERENCE, reference)
                    .putString(LAST_COMPONENT, clean(component, 120))
                    .putString(LAST_DETAIL, detail)
                    .putInt(FATAL_COUNT, nextCount)
                    .commit();
        } catch (RuntimeException ignored) {
            Log.e(TAG, "Unable to persist crash reference", ignored);
        }
        Log.e(TAG, reference + " / " + component, error);
        return reference;
    }

    private static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }

    private static String reference(String component, Throwable error, long now) {
        String type = error == null ? "Unknown" : error.getClass().getSimpleName();
        int hash = 17;
        hash = 31 * hash + clean(component, 120).hashCode();
        hash = 31 * hash + type.hashCode();
        if (error != null && error.getMessage() != null) hash = 31 * hash + error.getMessage().hashCode();
        return String.format(Locale.US, "DU-%08X-%04d", hash,
                Math.floorMod((int) (now / 1000L), 10_000));
    }

    private static String stack(Throwable error) {
        if (error == null) return "Unknown application failure";
        StringWriter output = new StringWriter();
        error.printStackTrace(new PrintWriter(output));
        return clean(output.toString(), MAX_DETAIL);
    }

    private static String clean(String value, int maximum) {
        String clean = value == null ? "" : value;
        return clean.length() <= maximum ? clean : clean.substring(0, maximum);
    }

    private static final class InstalledHandler implements Thread.UncaughtExceptionHandler {
        private final Context context;
        private final Thread.UncaughtExceptionHandler previous;

        InstalledHandler(Context context, Thread.UncaughtExceptionHandler previous) {
            this.context = context;
            this.previous = previous;
        }

        @Override
        public void uncaughtException(Thread thread, Throwable error) {
            String component = thread == null ? "unknown-thread" : thread.getName();
            record(context, component, error, true);
            if (previous != null) {
                previous.uncaughtException(thread, error);
            } else {
                Process.killProcess(Process.myPid());
                System.exit(10);
            }
        }
    }
}
