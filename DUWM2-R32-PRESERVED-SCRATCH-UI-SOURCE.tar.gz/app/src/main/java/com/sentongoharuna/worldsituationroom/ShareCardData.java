package com.sentongoharuna.worldsituationroom;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Immutable content model for one branded share card.  It intentionally carries source,
 * timestamp and credibility separately so a fast signal can never be shared as confirmed fact.
 */
public final class ShareCardData {
    public static final String BRAND = "DU WORLD MONITOR";
    public static final String TAGLINE = "SEE THE WORLD. HEAR THE LOCAL WITNESS.";

    public final String title;
    public final String summary;
    public final String status;
    public final String credibility;
    public final String category;
    public final String region;
    public final int severity;
    public final String source;
    public final String sourceUrl;
    public final long timestampMs;
    public final double latitude;
    public final double longitude;
    public final Map<String, String> facts;
    public final int accentColor;
    public final String disclaimer;

    public ShareCardData(
            String title,
            String summary,
            String status,
            String credibility,
            String category,
            String region,
            int severity,
            String source,
            String sourceUrl,
            long timestampMs,
            double latitude,
            double longitude,
            Map<String, String> facts,
            int accentColor,
            String disclaimer) {
        this.title = clean(title, "UNTITLED SIGNAL");
        this.summary = clean(summary, "No additional summary supplied by the source.");
        this.status = clean(status, "OBSERVED");
        this.credibility = clean(credibility, "SOURCE STATUS UNKNOWN");
        this.category = clean(category, "INFORMATION").toUpperCase(Locale.ROOT);
        this.region = clean(region, "GLOBAL").toUpperCase(Locale.ROOT);
        this.severity = Math.max(1, Math.min(5, severity));
        this.source = clean(source, "Unknown source");
        this.sourceUrl = sourceUrl == null ? "" : sourceUrl.trim();
        this.timestampMs = timestampMs > 0L ? timestampMs : System.currentTimeMillis();
        this.latitude = latitude;
        this.longitude = longitude;
        this.facts = Collections.unmodifiableMap(new LinkedHashMap<>(
                facts == null ? Collections.emptyMap() : facts));
        this.accentColor = accentColor;
        this.disclaimer = clean(disclaimer,
                "Verify at the original source. Observed information is not a forecast.");
    }

    public boolean hasLocation() {
        return !Double.isNaN(latitude) && !Double.isNaN(longitude)
                && latitude >= -90d && latitude <= 90d
                && longitude >= -180d && longitude <= 180d;
    }

    private static String clean(String value, String fallback) {
        if (value == null || value.trim().isEmpty()) return fallback;
        return value.trim().replaceAll("\\s+", " ");
    }
}
