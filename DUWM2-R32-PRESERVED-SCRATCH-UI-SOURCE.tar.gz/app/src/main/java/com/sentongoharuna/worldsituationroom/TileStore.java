package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;

/**
 * Bounded memory + disk cache for one raster family.
 *
 * R22 deliberately gives base imagery and transparent overlays separate stores. Visible base
 * tiles are pinned outside the ordinary LRU so a radar frame or label burst can never evict the
 * satellite image currently on screen. Requests are keyed, deduplicated and cancellable by
 * viewport; callers can therefore animate markers without restarting network work every frame.
 */
public final class TileStore {
    private final LruCache<String, Bitmap> memory;
    private final Map<String, Bitmap> pinnedMemory = new ConcurrentHashMap<>();
    private final File directory;
    private final long maxDiskBytes;
    private final boolean opaqueRgb565;
    private final ThreadPoolExecutor workers;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Set<String> pending = Collections.synchronizedSet(new HashSet<>());
    // Keep the concurrent interface visible to Android lint. ConcurrentMap has provided the
    // atomic remove(key, value) contract since API 1; java.util.Map only gained that overload in
    // API 24. The wider Map declaration therefore produced a false API-24 requirement on the
    // app's Android 6.0 (API 23) build even though the backing implementation was already safe.
    private final ConcurrentMap<String, TileTask> queuedTasks = new ConcurrentHashMap<>();
    private final Map<String, Long> failedAt = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, HttpsURLConnection> activeConnections =
            new ConcurrentHashMap<>();
    private volatile Set<String> viewportKeys = Collections.emptySet();

    public TileStore(
            Context context,
            String namespace,
            long requestedMemoryBytes,
            int memoryFractionDivisor,
            int workerCount,
            long maxDiskBytes,
            boolean opaqueRgb565) {
        String safeNamespace = namespace == null
                ? "tiles" : namespace.replaceAll("[^A-Za-z0-9._-]", "_");
        directory = new File(context.getApplicationContext().getCacheDir(),
                "native-map-tiles-v6-" + safeNamespace);
        if (!directory.exists()) directory.mkdirs();
        this.maxDiskBytes = Math.max(24L * 1024L * 1024L, maxDiskBytes);
        this.opaqueRgb565 = opaqueRgb565;
        long runtimeShare = Runtime.getRuntime().maxMemory()
                / Math.max(2, memoryFractionDivisor);
        int cacheBytes = (int) Math.min(Integer.MAX_VALUE,
                Math.max(8L * 1024L * 1024L,
                        Math.min(requestedMemoryBytes, runtimeShare)));
        memory = new LruCache<String, Bitmap>(cacheBytes) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getAllocationByteCount();
            }

            @Override
            protected void entryRemoved(
                    boolean evicted,
                    String key,
                    Bitmap oldValue,
                    Bitmap newValue) {
                // Keep a strong reference to currently visible imagery. The next viewport update
                // releases it naturally; bitmaps are never recycled while Canvas may be using one.
                if (evicted && viewportKeys.contains(key)
                        && oldValue != null && !oldValue.isRecycled()) {
                    pinnedMemory.put(key, oldValue);
                }
            }
        };
        int boundedWorkers = Math.max(1, Math.min(6, workerCount));
        workers = new ThreadPoolExecutor(boundedWorkers, boundedWorkers,
                0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>());
        workers.execute(this::trimDiskCache);
    }

    /** Returns memory-resident imagery without starting disk or network work. */
    public Bitmap peek(String key) {
        Bitmap pinned = pinnedMemory.get(key);
        if (pinned != null && !pinned.isRecycled()) return pinned;
        Bitmap cached = memory.get(key);
        return cached != null && !cached.isRecycled() ? cached : null;
    }

    public Bitmap request(
            String key,
            String primaryUrl,
            String fallbackUrl,
            long maxAgeMs,
            Runnable onReady) {
        Bitmap cached = peek(key);
        if (cached != null) return cached;
        Long failed = failedAt.get(key);
        if (failed != null && System.currentTimeMillis() - failed < 15_000L) return null;
        if (!pending.add(key)) return null;
        TileTask task = new TileTask(key, primaryUrl, fallbackUrl, maxAgeMs, onReady);
        queuedTasks.put(key, task);
        try {
            workers.execute(task);
        } catch (RejectedExecutionException ignored) {
            queuedTasks.remove(key, task);
            pending.remove(key);
        }
        return null;
    }

    /**
     * Pins the current viewport, discards only obsolete queued work and disconnects only requests
     * that have moved off-screen. Existing visible requests continue uninterrupted.
     */
    public void prioritizeViewport(Set<String> keepKeys) {
        Set<String> safe = keepKeys == null
                ? Collections.emptySet() : Collections.unmodifiableSet(new HashSet<>(keepKeys));
        viewportKeys = safe;
        for (String key : new HashSet<>(pinnedMemory.keySet())) {
            if (!safe.contains(key)) pinnedMemory.remove(key);
        }
        for (String key : safe) {
            Bitmap bitmap = memory.get(key);
            if (bitmap != null && !bitmap.isRecycled()) pinnedMemory.put(key, bitmap);
        }
        for (Runnable runnable : new HashSet<>(workers.getQueue())) {
            if (!(runnable instanceof TileTask)) continue;
            TileTask task = (TileTask) runnable;
            if (!safe.contains(task.key) && workers.getQueue().remove(task)) {
                queuedTasks.remove(task.key, task);
                pending.remove(task.key);
            }
        }
        for (Map.Entry<String, HttpsURLConnection> entry
                : new HashSet<>(activeConnections.entrySet())) {
            if (!safe.contains(entry.getKey())) entry.getValue().disconnect();
        }
    }

    public void shutdown() {
        cancelConnections();
        workers.shutdownNow();
        pending.clear();
        queuedTasks.clear();
        pinnedMemory.clear();
        memory.evictAll();
        failedAt.clear();
    }

    private final class TileTask implements Runnable {
        final String key;
        final String primaryUrl;
        final String fallbackUrl;
        final long maxAgeMs;
        final Runnable onReady;

        TileTask(
                String key,
                String primaryUrl,
                String fallbackUrl,
                long maxAgeMs,
                Runnable onReady) {
            this.key = key;
            this.primaryUrl = primaryUrl;
            this.fallbackUrl = fallbackUrl;
            this.maxAgeMs = maxAgeMs;
            this.onReady = onReady;
        }

        @Override
        public void run() {
            queuedTasks.remove(key, this);
            try {
                File file = fileFor(key);
                Bitmap bitmap = null;
                if (file.isFile() && System.currentTimeMillis() - file.lastModified() <= maxAgeMs) {
                    bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), decodeOptions());
                }
                if (bitmap == null) {
                    byte[] bytes = download(key, primaryUrl);
                    if (bytes == null && fallbackUrl != null && !fallbackUrl.trim().isEmpty()) {
                        bytes = download(key, fallbackUrl);
                    }
                    if (bytes != null) {
                        bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length,
                                decodeOptions());
                        if (bitmap != null) persistAtomically(file, bytes);
                    }
                }
                if (bitmap != null) {
                    failedAt.remove(key);
                    memory.put(key, bitmap);
                    if (viewportKeys.contains(key)) pinnedMemory.put(key, bitmap);
                    if (onReady != null) main.post(onReady);
                } else if (viewportKeys.isEmpty() || viewportKeys.contains(key)) {
                    failedAt.put(key, System.currentTimeMillis());
                }
            } catch (Exception ignored) {
                // A failed provider or cancelled off-screen request is isolated from the UI.
                if (viewportKeys.isEmpty() || viewportKeys.contains(key)) {
                    failedAt.put(key, System.currentTimeMillis());
                }
            } finally {
                pending.remove(key);
            }
        }
    }

    private BitmapFactory.Options decodeOptions() {
        BitmapFactory.Options options = new BitmapFactory.Options();
        if (opaqueRgb565) {
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            options.inDither = true;
        } else {
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        }
        return options;
    }

    private void persistAtomically(File file, byte[] bytes) {
        File temporary = new File(directory, file.getName() + ".tmp");
        try (FileOutputStream output = new FileOutputStream(temporary)) {
            output.write(bytes);
            output.flush();
            if (file.exists()) file.delete();
            if (!temporary.renameTo(file)) temporary.delete();
        } catch (Exception ignored) {
            temporary.delete();
        }
    }

    private byte[] download(String key, String url) {
        URL target;
        try {
            target = new URL(url);
            for (int redirect = 0; redirect <= 3; redirect++) {
                if (!"https".equalsIgnoreCase(target.getProtocol())) return null;
                HttpsURLConnection connection = (HttpsURLConnection) target.openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(5_000);
                connection.setReadTimeout(8_000);
                connection.setRequestProperty("User-Agent", AppConfig.USER_AGENT);
                connection.setRequestProperty("Accept", "image/png,image/jpeg,image/webp,*/*");
                activeConnections.put(key, connection);
                try {
                    int code = connection.getResponseCode();
                    if (code >= 300 && code < 400) {
                        String location = connection.getHeaderField("Location");
                        if (location == null || location.trim().isEmpty()) return null;
                        target = new URL(target, location);
                        continue;
                    }
                    if (code < 200 || code >= 300) return null;
                    int declared = connection.getContentLength();
                    if (declared > 5 * 1024 * 1024) return null;
                    try (InputStream input = connection.getInputStream();
                         ByteArrayOutputStream output = new ByteArrayOutputStream(
                                 declared > 0 ? declared : 32 * 1024)) {
                        byte[] buffer = new byte[16 * 1024];
                        int total = 0;
                        int read;
                        while ((read = input.read(buffer)) != -1) {
                            total += read;
                            if (total > 5 * 1024 * 1024) return null;
                            output.write(buffer, 0, read);
                        }
                        return output.toByteArray();
                    }
                } finally {
                    activeConnections.remove(key, connection);
                    connection.disconnect();
                }
            }
        } catch (Exception ignored) {
            // The caller keeps a pinned parent tile or deterministic native placeholder visible.
        }
        return null;
    }

    private void cancelConnections() {
        for (HttpsURLConnection connection : activeConnections.values()) connection.disconnect();
        activeConnections.clear();
    }

    private File fileFor(String key) {
        String name = Integer.toHexString(key.hashCode()) + "_"
                + key.replaceAll("[^A-Za-z0-9._-]", "_");
        if (name.length() > 110) name = name.substring(0, 110);
        return new File(directory, name + ".tile");
    }

    private void trimDiskCache() {
        File[] files = directory.listFiles((dir, name) -> name.endsWith(".tile"));
        if (files == null) return;
        long total = 0L;
        for (File file : files) total += file.length();
        if (total <= maxDiskBytes) return;
        java.util.Arrays.sort(files, (first, second) -> {
            long firstModified = first.lastModified();
            long secondModified = second.lastModified();
            return firstModified == secondModified ? 0 : firstModified < secondModified ? -1 : 1;
        });
        for (File file : files) {
            if (total <= maxDiskBytes * 3L / 4L) break;
            long size = file.length();
            if (file.delete()) total -= size;
        }
    }
}
