package com.sentongoharuna.worldsituationroom;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Locale;

/** One source-attributed item displayed on the map, ticker, or detail desk. */
public final class Signal {
    public enum Layer {
        FLIGHTS,
        SHIPS,
        WEATHER,
        AIRSPACE,
        NATURAL,
        NEWS,
        SATELLITES,
        SPACE_WEATHER,
        INFRASTRUCTURE,
        MARKETS,
        WEBCAMS,
        RADIO,
        TV,
        MEDIA
    }
    public enum Credibility {
        RAW_SIGNAL,
        /** Position or value calculated from named public source data, not live telemetry. */
        CALCULATED,
        UNVERIFIED,
        REPORTED,
        CONFIRMED,
        PUBLIC_SOURCE
    }

    public final String id;
    public final Layer layer;
    public final String title;
    public final String summary;
    public final double latitude;
    public final double longitude;
    public final double heading;
    /** Provider-reported ground speed. NaN means that this source exposes no speed. */
    public final double speedMetersPerSecond;
    public final long timestampMs;
    public final String source;
    public final String sourceUrl;
    public final Credibility credibility;
    public final String eventType;
    public final String region;
    public final int severity;
    public final Map<String, String> facts;

    public Signal(
            String id,
            Layer layer,
            String title,
            String summary,
            double latitude,
            double longitude,
            double heading,
            long timestampMs,
            String source,
            String sourceUrl,
            Credibility credibility,
            String eventType,
            String region,
            int severity,
            Map<String, String> facts) {
        this(id, layer, title, summary, latitude, longitude, heading,
                Double.NaN, timestampMs, source, sourceUrl, credibility,
                eventType, region, severity, facts);
    }

    public Signal(
            String id,
            Layer layer,
            String title,
            String summary,
            double latitude,
            double longitude,
            double heading,
            double speedMetersPerSecond,
            long timestampMs,
            String source,
            String sourceUrl,
            Credibility credibility,
            String eventType,
            String region,
            int severity,
            Map<String, String> facts) {
        this.id = id;
        this.layer = layer;
        this.title = title == null || title.trim().isEmpty() ? "UNTITLED SIGNAL" : title.trim();
        this.summary = summary == null ? "" : summary.trim();
        this.latitude = latitude;
        this.longitude = longitude;
        this.heading = heading;
        this.speedMetersPerSecond = speedMetersPerSecond;
        this.timestampMs = timestampMs;
        this.source = source == null || source.trim().isEmpty() ? "Unknown source" : source.trim();
        this.sourceUrl = sourceUrl == null ? "" : sourceUrl.trim();
        this.credibility = credibility;
        this.eventType = eventType == null ? "OTHER" : eventType.toUpperCase(Locale.ROOT);
        this.region = region == null ? "GLOBAL" : region.toUpperCase(Locale.ROOT);
        this.severity = Math.max(1, Math.min(5, severity));
        this.facts = Collections.unmodifiableMap(new LinkedHashMap<>(facts));
    }

    public boolean hasLocation() {
        return !Double.isNaN(latitude)
                && !Double.isNaN(longitude)
                && latitude >= -90d && latitude <= 90d
                && longitude >= -180d && longitude <= 180d;
    }

    public Signal withCredibility(Credibility value) {
        return new Signal(id, layer, title, summary, latitude, longitude, heading,
                speedMetersPerSecond,
                timestampMs, source, sourceUrl, value, eventType, region, severity, facts);
    }
}
