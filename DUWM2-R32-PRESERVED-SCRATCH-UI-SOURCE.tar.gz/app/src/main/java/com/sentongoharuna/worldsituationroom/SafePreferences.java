package com.sentongoharuna.worldsituationroom;

import android.content.SharedPreferences;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Type-tolerant preference reads for upgrade safety.
 *
 * Android's typed SharedPreferences getters throw ClassCastException when an older build wrote
 * the same key with another type.  A stale preference must never make the application disappear,
 * so every read goes through the untyped map and accepts only a safe conversion.
 */
public final class SafePreferences {
    private SafePreferences() { }

    public static String string(SharedPreferences preferences, String key, String fallback) {
        Object value = value(preferences, key);
        if (value instanceof String) return (String) value;
        if (value instanceof Number || value instanceof Boolean) return String.valueOf(value);
        return fallback;
    }

    public static int integer(SharedPreferences preferences, String key, int fallback) {
        Object value = value(preferences, key);
        if (value instanceof Number) return ((Number) value).intValue();
        if (value instanceof String) {
            try {
                return Integer.parseInt(((String) value).trim());
            } catch (Exception ignored) { }
        }
        return fallback;
    }

    public static long longValue(SharedPreferences preferences, String key, long fallback) {
        Object value = value(preferences, key);
        if (value instanceof Number) return ((Number) value).longValue();
        if (value instanceof String) {
            try {
                return Long.parseLong(((String) value).trim());
            } catch (Exception ignored) { }
        }
        return fallback;
    }

    public static boolean bool(SharedPreferences preferences, String key, boolean fallback) {
        Object value = value(preferences, key);
        if (value instanceof Boolean) return (Boolean) value;
        if (value instanceof Number) return ((Number) value).intValue() != 0;
        if (value instanceof String) {
            String clean = ((String) value).trim();
            if ("true".equalsIgnoreCase(clean) || "1".equals(clean)) return true;
            if ("false".equalsIgnoreCase(clean) || "0".equals(clean)) return false;
        }
        return fallback;
    }

    public static Set<String> stringSet(
            SharedPreferences preferences,
            String key,
            Set<String> fallback) {
        Object value = value(preferences, key);
        if (!(value instanceof Set<?>)) {
            return new HashSet<>(fallback == null ? Collections.emptySet() : fallback);
        }
        Set<String> result = new HashSet<>();
        for (Object item : (Set<?>) value) {
            if (item instanceof String) result.add((String) item);
        }
        return result;
    }

    private static Object value(SharedPreferences preferences, String key) {
        if (preferences == null || key == null) return null;
        try {
            Map<String, ?> all = preferences.getAll();
            return all == null ? null : all.get(key);
        } catch (RuntimeException ignored) {
            return null;
        }
    }
}
