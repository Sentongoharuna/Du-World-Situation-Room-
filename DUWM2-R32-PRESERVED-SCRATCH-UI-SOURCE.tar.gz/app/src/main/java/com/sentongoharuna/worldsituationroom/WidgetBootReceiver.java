package com.sentongoharuna.worldsituationroom;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restores widget scheduling after reboot; it performs no network request in the receiver. */
public final class WidgetBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent == null ? null : intent.getAction())
                && DuWidgetUpdater.hasWidgets(context)) {
            WidgetRefreshScheduler.schedulePeriodic(context);
            DuWidgetUpdater.requestUpdate(context);
        }
    }
}
