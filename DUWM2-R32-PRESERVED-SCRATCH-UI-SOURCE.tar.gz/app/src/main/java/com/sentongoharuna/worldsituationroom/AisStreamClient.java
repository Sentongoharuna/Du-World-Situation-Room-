package com.sentongoharuna.worldsituationroom;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Iterator;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** Optional native AISStream WebSocket client. The user's key is never embedded in the APK. */
public final class AisStreamClient {
    public interface Listener {
        void onSnapshot(List<Signal> vessels, FeedStatus status);
    }

    private static final long STALE_MS = 20L * 60L * 1000L;
    private final SecurePrefs securePrefs;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ScheduledExecutorService retryExecutor =
            Executors.newSingleThreadScheduledExecutor();
    private final Map<String, Vessel> vessels = new LinkedHashMap<>();
    private volatile boolean running;
    private volatile NativeWebSocket socket;
    private int reconnectAttempt;
    private long lastPublishMs;
    private double viewportSouth = -90d;
    private double viewportWest = -180d;
    private double viewportNorth = 90d;
    private double viewportEast = 180d;
    private boolean detailedViewport;
    private long lastSubscriptionUpdateMs;
    private boolean subscriptionResendQueued;

    public AisStreamClient(SecurePrefs securePrefs, Listener listener) {
        this.securePrefs = securePrefs;
        this.listener = listener;
    }

    public synchronized void start() {
        stopSocketOnly();
        running = true;
        String key = securePrefs.get(SecurePrefs.AIS_KEY);
        if (key.trim().isEmpty()) {
            post(new ArrayList<>(), new FeedStatus(FeedStatus.State.KEY_REQUIRED, 0,
                    "Add an AISStream key in Settings", System.currentTimeMillis()));
            return;
        }
        connect(key);
    }

    public synchronized void stop() {
        running = false;
        stopSocketOnly();
        retryExecutor.shutdownNow();
    }

    /** Replaces the AISStream subscription with the current native map bounds. */
    public synchronized void updateViewport(SatelliteMapView.Bounds bounds, boolean detailed) {
        if (bounds == null) return;
        viewportSouth = clamp(bounds.south, -90d, 90d);
        viewportWest = clamp(bounds.west, -180d, 180d);
        viewportNorth = clamp(bounds.north, -90d, 90d);
        viewportEast = clamp(bounds.east, -180d, 180d);
        detailedViewport = detailed;
        if (!running || socket == null) return;
        long wait = Math.max(0L, 1_250L - (System.currentTimeMillis() - lastSubscriptionUpdateMs));
        if (wait == 0L) {
            sendCurrentSubscription();
        } else if (!subscriptionResendQueued && !retryExecutor.isShutdown()) {
            subscriptionResendQueued = true;
            retryExecutor.schedule(() -> {
                synchronized (AisStreamClient.this) {
                    subscriptionResendQueued = false;
                    sendCurrentSubscription();
                }
            }, wait, TimeUnit.MILLISECONDS);
        }
    }

    private void connect(String key) {
        if (!running) {
            return;
        }
        post(snapshot(), FeedStatus.loading("Connecting to AISStream"));
        NativeWebSocket webSocket = new NativeWebSocket(
                AppConfig.AIS_STREAM, AppConfig.USER_AGENT, new NativeWebSocket.Listener() {
            @Override
            public void onOpen(NativeWebSocket webSocket) {
                reconnectAttempt = 0;
                synchronized (AisStreamClient.this) {
                    lastSubscriptionUpdateMs = System.currentTimeMillis();
                    webSocket.send(subscription(key).toString());
                }
            }

            @Override
            public void onText(NativeWebSocket webSocket, String text) {
                consume(text);
            }

            @Override
            public void onClosed(NativeWebSocket webSocket, int code, String reason) {
                scheduleReconnect("closed " + code + (reason.isEmpty() ? "" : " — " + reason));
            }

            @Override
            public void onFailure(NativeWebSocket webSocket, Throwable error) {
                scheduleReconnect(error.getMessage());
            }
        });
        socket = webSocket;
        webSocket.connect();
    }

    private JSONObject subscription(String key) {
        try {
            JSONObject value = new JSONObject();
            value.put("APIKey", key);
            value.put("BoundingBoxes", boundingBoxes());
            value.put("FilterMessageTypes", new JSONArray()
                    .put("PositionReport")
                    .put("StandardClassBPositionReport")
                    .put("ExtendedClassBPositionReport")
                    .put("ShipStaticData")
                    .put("StaticDataReport"));
            return value;
        } catch (Exception impossible) {
            return new JSONObject();
        }
    }

    private synchronized JSONArray boundingBoxes() throws JSONException {
        JSONArray boxes = new JSONArray();
        if (!detailedViewport) {
            return boxes.put(box(-90d, -180d, 90d, 180d));
        }
        double south = Math.min(viewportSouth, viewportNorth);
        double north = Math.max(viewportSouth, viewportNorth);
        if (viewportWest <= viewportEast) {
            boxes.put(box(south, viewportWest, north, viewportEast));
        } else {
            // A viewport crossing the date line is represented by two legal boxes.
            boxes.put(box(south, viewportWest, north, 180d));
            boxes.put(box(south, -180d, north, viewportEast));
        }
        return boxes;
    }

    private static JSONArray box(double south, double west, double north, double east)
            throws JSONException {
        return new JSONArray()
                .put(new JSONArray().put(south).put(west))
                .put(new JSONArray().put(north).put(east));
    }

    private synchronized void sendCurrentSubscription() {
        NativeWebSocket current = socket;
        String key = securePrefs.get(SecurePrefs.AIS_KEY);
        if (!running || current == null || key.trim().isEmpty()) return;
        lastSubscriptionUpdateMs = System.currentTimeMillis();
        current.send(subscription(key).toString());
        List<Signal> currentSignals = snapshot();
        post(currentSignals, new FeedStatus(FeedStatus.State.LOADING, currentSignals.size(),
                detailedViewport ? "Switching AIS to visible map sector"
                        : "Switching AIS to global overview",
                System.currentTimeMillis()));
    }

    private synchronized void consume(String text) {
        try {
            JSONObject root = new JSONObject(text);
            String messageType = root.optString("MessageType", "");
            if (messageType.equals("SubscriptionConfirmation")) {
                post(snapshot(), new FeedStatus(FeedStatus.State.LIVE, vessels.size(),
                        detailedViewport ? "AIS sector stream connected"
                                : "AIS global stream connected",
                        System.currentTimeMillis()));
                return;
            }
            JSONObject metadata = root.optJSONObject("MetaData");
            if (metadata == null) {
                return;
            }
            String mmsi = String.valueOf(metadata.optLong("MMSI", 0L));
            if (mmsi.equals("0")) {
                return;
            }
            Vessel vessel = vessels.get(mmsi);
            if (vessel == null) {
                vessel = new Vessel(mmsi);
                vessels.put(mmsi, vessel);
            }
            vessel.name = clean(metadata.optString("ShipName", vessel.name));
            if (metadata.has("Latitude") && metadata.has("Longitude")) {
                double latitude = metadata.optDouble("Latitude", Double.NaN);
                double longitude = metadata.optDouble("Longitude", Double.NaN);
                if (valid(latitude, longitude)) {
                    vessel.latitude = latitude;
                    vessel.longitude = longitude;
                }
            }
            JSONObject envelope = root.optJSONObject("Message");
            JSONObject payload = envelope == null ? null : envelope.optJSONObject(messageType);
            if (payload != null) {
                vessel.speedKnots = firstDouble(payload, "Sog", "SpeedOverGround");
                vessel.heading = firstDouble(payload, "TrueHeading", "Cog", "CourseOverGround");
                String destination = clean(payload.optString("Destination", ""));
                if (!destination.trim().isEmpty()) vessel.destination = destination;
                int typeCode = payload.optInt("TypeAndCargoType",
                        payload.optInt("ShipType", vessel.typeCode));
                if (typeCode > 0) vessel.typeCode = typeCode;
                String callSign = clean(payload.optString("CallSign", ""));
                if (!callSign.trim().isEmpty()) vessel.callSign = callSign;
            }
            vessel.lastSeenMs = System.currentTimeMillis();
            removeStale();
            if (vessel.hasLocation() && System.currentTimeMillis() - lastPublishMs > 1200L) {
                lastPublishMs = System.currentTimeMillis();
                List<Signal> current = snapshot();
                post(current, new FeedStatus(FeedStatus.State.LIVE, current.size(),
                        detailedViewport ? "Live AIS positions • visible sector"
                                : "Live AIS positions • global overview",
                        System.currentTimeMillis()));
            }
        } catch (Exception ignored) {
            // Malformed individual AIS messages are skipped without affecting the stream.
        }
    }

    private synchronized List<Signal> snapshot() {
        List<Signal> result = new ArrayList<>();
        for (Vessel vessel : vessels.values()) {
            if (!vessel.hasLocation()) continue;
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("MMSI", vessel.mmsi);
            facts.put("TYPE", typeName(vessel.typeCode));
            facts.put("FLAG / MID", midName(vessel.mmsi));
            facts.put("DESTINATION", vessel.destination.trim().isEmpty() ? "Not reported" : vessel.destination);
            facts.put("SPEED", Double.isNaN(vessel.speedKnots)
                    ? "Not reported" : String.format(Locale.US, "%.1f kn", vessel.speedKnots));
            facts.put("HEADING", Double.isNaN(vessel.heading)
                    ? "Not reported" : String.format(Locale.US, "%.0f°", vessel.heading));
            facts.put("POSITION MODE", "Provider fix; motion estimated for at most 120 s");
            facts.put("TIMESTAMP TYPE", "AIS packet received by this device");
            facts.put("COVERAGE", detailedViewport ? "Current detailed map sector"
                    : "Global overview");
            if (!vessel.callSign.trim().isEmpty()) facts.put("CALL SIGN", vessel.callSign);
            result.add(new Signal(
                    "ais-" + vessel.mmsi,
                    Signal.Layer.SHIPS,
                    vessel.name.trim().isEmpty() ? "VESSEL " + vessel.mmsi : vessel.name,
                    "Live AIS position report",
                    vessel.latitude,
                    vessel.longitude,
                    vessel.heading,
                    Double.isNaN(vessel.speedKnots)
                            ? Double.NaN : vessel.speedKnots * 0.514444d,
                    vessel.lastSeenMs,
                    "AISStream.io",
                    "https://aisstream.io",
                    Signal.Credibility.RAW_SIGNAL,
                    "MARITIME",
                    "GLOBAL",
                    1,
                    facts));
        }
        Collections.sort(result, (first, second) ->
                first.timestampMs == second.timestampMs ? 0
                        : first.timestampMs < second.timestampMs ? 1 : -1);
        if (result.size() > 2500) {
            return new ArrayList<>(result.subList(0, 2500));
        }
        return result;
    }

    private void scheduleReconnect(String reason) {
        if (!running || retryExecutor.isShutdown()) {
            return;
        }
        long delay = Math.min(60L, 2L << Math.min(5, reconnectAttempt++));
        List<Signal> current = snapshot();
        post(current, new FeedStatus(current.isEmpty()
                        ? FeedStatus.State.OFFLINE : FeedStatus.State.CACHED,
                current.size(),
                "AIS interrupted; retrying in " + delay + "s"
                        + (reason == null ? "" : " — " + reason),
                System.currentTimeMillis()));
        retryExecutor.schedule(() -> connect(securePrefs.get(SecurePrefs.AIS_KEY)),
                delay, TimeUnit.SECONDS);
    }

    private void post(List<Signal> snapshot, FeedStatus status) {
        main.post(() -> listener.onSnapshot(snapshot, status));
    }

    private synchronized void removeStale() {
        long threshold = System.currentTimeMillis() - STALE_MS;
        Iterator<Map.Entry<String, Vessel>> iterator = vessels.entrySet().iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getValue().lastSeenMs < threshold) iterator.remove();
        }
    }

    private synchronized void stopSocketOnly() {
        NativeWebSocket current = socket;
        socket = null;
        if (current != null) {
            current.close(1000, "DU World Monitor paused");
            current.cancel();
        }
    }

    private static boolean valid(double latitude, double longitude) {
        return !Double.isNaN(latitude) && !Double.isNaN(longitude)
                && latitude >= -90d && latitude <= 90d
                && longitude >= -180d && longitude <= 180d
                && !(latitude == 0d && longitude == 0d);
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static double firstDouble(JSONObject value, String... keys) {
        for (String key : keys) {
            if (value.has(key)) {
                double number = value.optDouble(key, Double.NaN);
                if (!Double.isNaN(number)) return number;
            }
        }
        return Double.NaN;
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim().replace("@", "");
    }

    private static String typeName(int code) {
        if (code >= 70 && code < 80) return "Cargo";
        if (code >= 80 && code < 90) return "Tanker";
        if (code >= 60 && code < 70) return "Passenger";
        if (code >= 50 && code < 60) return "Service / special craft";
        if (code >= 40 && code < 50) return "High-speed craft";
        if (code >= 30 && code < 40) return "Fishing / towing / sailing";
        return code > 0 ? "AIS type " + code : "Not reported";
    }

    private static String midName(String mmsi) {
        if (mmsi.length() < 3) return "Unknown";
        String mid = mmsi.substring(0, 3);
        switch (mid) {
            case "657": return "Nigeria (657)";
            case "650": return "Mozambique (650)";
            case "634": return "Kenya (634)";
            case "677": return "Tanzania (677)";
            case "232": case "233": case "234": case "235": return "United Kingdom (" + mid + ")";
            case "366": case "367": case "368": case "369": return "United States (" + mid + ")";
            case "338": return "United States (338)";
            case "503": return "Australia (503)";
            case "412": case "413": case "414": return "China (" + mid + ")";
            case "431": case "432": return "Japan (" + mid + ")";
            default: return "MID " + mid;
        }
    }

    private static final class Vessel {
        final String mmsi;
        String name = "";
        String destination = "";
        String callSign = "";
        double latitude = Double.NaN;
        double longitude = Double.NaN;
        double heading = Double.NaN;
        double speedKnots = Double.NaN;
        int typeCode;
        long lastSeenMs;

        Vessel(String mmsi) {
            this.mmsi = mmsi;
        }

        boolean hasLocation() {
            return valid(latitude, longitude);
        }
    }
}
