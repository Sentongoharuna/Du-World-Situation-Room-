package com.sentongoharuna.worldsituationroom;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Single serialized renderer for every widget instance. Snapshot parsing and globe drawing stay
 * off the broadcast receiver's main thread, and rapid feed updates collapse into one redraw.
 */
public final class DuWidgetUpdater {
    private static final String LOG_TAG = "DuWidgetUpdater";
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final AtomicBoolean DEBOUNCE_PENDING = new AtomicBoolean(false);

    private DuWidgetUpdater() { }

    public static void requestUpdate(Context context) {
        Context app = context.getApplicationContext();
        if (!DEBOUNCE_PENDING.compareAndSet(false, true)) return;
        MAIN.postDelayed(() -> {
            DEBOUNCE_PENDING.set(false);
            updateAll(app);
        }, 850L);
    }

    public static void updateAll(Context context) {
        Context app = context.getApplicationContext();
        WORKER.execute(() -> renderAll(app));
    }

    public static void updateSingle(Context context, int widgetId,
                                    DuWidgetContract.Kind fallback) {
        Context app = context.getApplicationContext();
        WORKER.execute(() -> {
            AppWidgetManager manager = AppWidgetManager.getInstance(app);
            DuWidgetPreferences profiles = new DuWidgetPreferences(app);
            DuWidgetContract.Kind kind = fallback == null
                    ? profiles.inferKind(widgetId) : fallback;
            renderOne(app, manager, profiles, WidgetSnapshot.load(app), widgetId, kind);
        });
    }

    /** Gives the launcher a valid surface before asynchronous parsing/network work begins. */
    public static void showStartingState(Context context, int widgetId,
                                         DuWidgetContract.Kind kind) {
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return;
        try {
            AppWidgetManager.getInstance(context).updateAppWidget(widgetId,
                    DuWidgetRenderer.renderStarting(context, widgetId, kind, false));
        } catch (RuntimeException error) {
            Log.w(LOG_TAG, "Launcher rejected widget starting surface", error);
        }
    }

    private static void renderAll(Context app) {
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        DuWidgetPreferences profiles = new DuWidgetPreferences(app);
        WidgetSnapshot snapshot = WidgetSnapshot.load(app);
        for (DuWidgetContract.Kind kind : DuWidgetContract.Kind.values()) {
            ComponentName provider = DuWidgetContract.component(app, kind);
            int[] ids = manager.getAppWidgetIds(provider);
            for (int widgetId : ids) {
                renderOne(app, manager, profiles, snapshot, widgetId, kind);
            }
        }
    }

    private static void renderOne(Context app, AppWidgetManager manager,
                                  DuWidgetPreferences profiles, WidgetSnapshot snapshot,
                                  int widgetId, DuWidgetContract.Kind kind) {
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return;
        DuWidgetPreferences.Config config = profiles.load(widgetId, kind);
        Bundle options = manager.getAppWidgetOptions(widgetId);
        try {
            manager.updateAppWidget(widgetId,
                    DuWidgetRenderer.render(app, widgetId, kind, config, snapshot, options));
        } catch (RuntimeException error) {
            Log.e(LOG_TAG, "Rich widget render failed; applying safe layout", error);
            try {
                manager.updateAppWidget(widgetId,
                        DuWidgetRenderer.renderStarting(app, widgetId, kind, true));
            } catch (RuntimeException recoveryError) {
                Log.e(LOG_TAG, "Launcher rejected safe widget layout", recoveryError);
            }
        }
    }

    public static boolean hasWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        for (DuWidgetContract.Kind kind : DuWidgetContract.Kind.values()) {
            if (manager.getAppWidgetIds(DuWidgetContract.component(context, kind)).length > 0) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasBackgroundWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        DuWidgetPreferences profiles = new DuWidgetPreferences(context);
        for (DuWidgetContract.Kind kind : DuWidgetContract.Kind.values()) {
            for (int widgetId : manager.getAppWidgetIds(
                    DuWidgetContract.component(context, kind))) {
                if (profiles.load(widgetId, kind).backgroundRefresh) return true;
            }
        }
        return false;
    }
}
