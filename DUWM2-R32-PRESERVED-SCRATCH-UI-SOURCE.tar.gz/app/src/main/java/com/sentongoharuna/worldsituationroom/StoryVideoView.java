package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.Surface;
import android.view.TextureView;

/**
 * Small dependency-free video surface for the Local Monitors story feed.
 * Android's stock VideoView measures itself to the source aspect ratio, which produced the
 * wide black rail seen on tall phones. This view always owns the full stage and explicitly
 * transforms the video into either centre-crop (FILL) or letterboxed (FIT) presentation.
 */
public final class StoryVideoView extends TextureView
        implements TextureView.SurfaceTextureListener {

    private Uri source;
    private MediaPlayer player;
    private Surface surface;
    private int videoWidth;
    private int videoHeight;
    private boolean fillMode = true;
    private boolean muted;
    private boolean startWhenReady;
    private boolean looping = true;
    private int generation;
    private MediaPlayer.OnPreparedListener preparedListener;
    private MediaPlayer.OnErrorListener errorListener;
    private MediaPlayer.OnInfoListener infoListener;
    private MediaPlayer.OnCompletionListener completionListener;

    public StoryVideoView(Context context) {
        super(context);
        initialise();
    }

    public StoryVideoView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialise();
    }

    private void initialise() {
        setSurfaceTextureListener(this);
        setOpaque(true);
    }

    public void setVideoURI(Uri uri) {
        source = uri;
        prepareIfReady();
    }

    public void setOnPreparedListener(MediaPlayer.OnPreparedListener listener) {
        preparedListener = listener;
    }

    public void setOnErrorListener(MediaPlayer.OnErrorListener listener) {
        errorListener = listener;
    }

    public void setOnInfoListener(MediaPlayer.OnInfoListener listener) {
        infoListener = listener;
    }

    public void setOnCompletionListener(MediaPlayer.OnCompletionListener listener) {
        completionListener = listener;
    }

    public void setLooping(boolean value) {
        looping = value;
        if (player != null) {
            try {
                player.setLooping(value);
            } catch (IllegalStateException ignored) { }
        }
    }

    public boolean toggleFillMode() {
        fillMode = !fillMode;
        applyVideoTransform();
        return fillMode;
    }

    public boolean isFillMode() {
        return fillMode;
    }

    public void setMuted(boolean value) {
        muted = value;
        if (player != null) {
            float volume = muted ? 0f : 1f;
            try {
                player.setVolume(volume, volume);
            } catch (IllegalStateException ignored) { }
        }
    }

    public void start() {
        startWhenReady = true;
        if (player != null) {
            try {
                player.start();
            } catch (IllegalStateException ignored) { }
        }
    }

    public void pause() {
        startWhenReady = false;
        if (player != null) {
            try {
                player.pause();
            } catch (IllegalStateException ignored) { }
        }
    }

    public boolean isPlaying() {
        if (player == null) return false;
        try {
            return player.isPlaying();
        } catch (IllegalStateException ignored) {
            return false;
        }
    }

    public int getCurrentPosition() {
        if (player == null) return 0;
        try {
            return Math.max(0, player.getCurrentPosition());
        } catch (IllegalStateException ignored) {
            return 0;
        }
    }

    public int getDuration() {
        if (player == null) return 0;
        try {
            return Math.max(0, player.getDuration());
        } catch (IllegalStateException ignored) {
            return 0;
        }
    }

    public void seekTo(int milliseconds) {
        if (player == null) return;
        try {
            player.seekTo(Math.max(0, milliseconds));
        } catch (IllegalStateException ignored) { }
    }

    public void stopPlayback() {
        startWhenReady = false;
        releasePlayer();
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void prepareIfReady() {
        if (source == null || !isAvailable()) return;
        releasePlayer();
        final int requestGeneration = ++generation;
        try {
            SurfaceTexture texture = getSurfaceTexture();
            if (texture == null) return;
            surface = new Surface(texture);
            MediaPlayer created = new MediaPlayer();
            player = created;
            created.setAudioAttributes(new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build());
            created.setDataSource(getContext(), source);
            created.setSurface(surface);
            created.setLooping(looping);
            created.setVolume(muted ? 0f : 1f, muted ? 0f : 1f);
            created.setOnVideoSizeChangedListener((ignored, width, height) -> {
                if (!isCurrent(created, requestGeneration)) return;
                videoWidth = Math.max(0, width);
                videoHeight = Math.max(0, height);
                applyVideoTransform();
            });
            created.setOnInfoListener((ignored, what, extra) -> {
                if (!isCurrent(created, requestGeneration)) return true;
                try {
                    return infoListener != null && infoListener.onInfo(ignored, what, extra);
                } catch (RuntimeException callbackFailure) {
                    return true;
                }
            });
            created.setOnCompletionListener(ignored -> {
                if (!isCurrent(created, requestGeneration)) return;
                try {
                    if (completionListener != null) completionListener.onCompletion(ignored);
                } catch (RuntimeException ignoredCallback) { }
            });
            created.setOnErrorListener((ignored, what, extra) -> {
                if (!isCurrent(created, requestGeneration)) return true;
                try {
                    if (errorListener != null) return errorListener.onError(ignored, what, extra);
                } catch (RuntimeException ignoredCallback) { }
                return true;
            });
            created.setOnPreparedListener(ignored -> {
                if (!isCurrent(created, requestGeneration)) return;
                videoWidth = Math.max(0, ignored.getVideoWidth());
                videoHeight = Math.max(0, ignored.getVideoHeight());
                applyVideoTransform();
                try {
                    if (preparedListener != null) preparedListener.onPrepared(ignored);
                } catch (RuntimeException ignoredCallback) { }
                if (startWhenReady) {
                    try {
                        ignored.start();
                    } catch (IllegalStateException ignoredState) { }
                }
            });
            created.prepareAsync();
        } catch (Exception | OutOfMemoryError error) {
            releasePlayer();
            try {
                if (errorListener != null) errorListener.onError(null,
                        MediaPlayer.MEDIA_ERROR_UNKNOWN, 0);
            } catch (RuntimeException ignored) { }
        }
    }

    private boolean isCurrent(MediaPlayer candidate, int requestGeneration) {
        return candidate != null && candidate == player && requestGeneration == generation;
    }

    private void applyVideoTransform() {
        int viewWidth = getWidth();
        int viewHeight = getHeight();
        if (viewWidth <= 0 || viewHeight <= 0 || videoWidth <= 0 || videoHeight <= 0) return;
        float scaleX = (float) viewWidth / (float) videoWidth;
        float scaleY = (float) viewHeight / (float) videoHeight;
        float scale = fillMode ? Math.max(scaleX, scaleY) : Math.min(scaleX, scaleY);
        float targetWidth = videoWidth * scale;
        float targetHeight = videoHeight * scale;
        float transformX = targetWidth / viewWidth;
        float transformY = targetHeight / viewHeight;
        Matrix matrix = new Matrix();
        matrix.setScale(transformX, transformY, viewWidth / 2f, viewHeight / 2f);
        setTransform(matrix);
    }

    private void releasePlayer() {
        generation++;
        MediaPlayer existing = player;
        player = null;
        if (existing != null) {
            try {
                existing.reset();
            } catch (Exception ignored) { }
            try {
                existing.release();
            } catch (Exception ignored) { }
        }
        if (surface != null) {
            surface.release();
            surface = null;
        }
        videoWidth = 0;
        videoHeight = 0;
        setTransform(new Matrix());
    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        applyVideoTransform();
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture texture, int width, int height) {
        prepareIfReady();
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture texture, int width, int height) {
        applyVideoTransform();
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture texture) {
        releasePlayer();
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture texture) { }
}
