package com.sentongoharuna.worldsituationroom;

import android.content.ComponentName;
import android.content.Context;

/** Stable widget identities, deep-link contracts and picker metadata for R27. */
public final class DuWidgetContract {
    public static final String EXTRA_OPEN_CATALOG = "du.widget.OPEN_CATALOG";
    public static final String EXTRA_WIDGET_ID = "du.widget.ID";
    public static final String EXTRA_WIDGET_KIND = "du.widget.KIND";
    public static final String ACTION_REFRESH = "com.sentongoharuna.worldsituationroom.widget.REFRESH";
    public static final String ACTION_NEXT = "com.sentongoharuna.worldsituationroom.widget.NEXT";
    public static final String ACTION_PREVIOUS = "com.sentongoharuna.worldsituationroom.widget.PREVIOUS";

    public enum Kind {
        ALERT("ALERT", "DU ALERT BEACON", "EVENTS", "AlertBeacon", 1, 1,
                "Priority signal count and latest severe source-attributed event."),
        COUNTERS("COUNTERS", "DU LIVE COUNTERS", "SOURCES", "LiveCounters", 2, 1,
                "Provider-returned air, sea, event, orbit and media totals."),
        LOCAL("LOCAL", "DU LOCAL WATCH", "BRIEF", "LocalWatch", 2, 2,
                "A configurable regional watch with truthful source freshness."),
        WIRE("WIRE", "DU BREAKING WIRE", "NEWS", "BreakingWire", 4, 1,
                "Newest headline with credibility, source and exact acquisition age."),
        AIR_SEA("AIR_SEA", "DU AIR & SEA TRACKER", "AIRCRAFT", "AirSeaTracker", 4, 2,
                "Aircraft and vessel movement readouts from acquired public telemetry."),
        HAZARDS("HAZARDS", "DU HAZARDS & WEATHER", "EVENTS", "HazardsWeather", 4, 2,
                "Earthquakes, storms, fires, SIGMETs, space weather and radar health."),
        MEDIA("MEDIA", "DU MEDIA WATCH", "CAMERAS", "MediaWatch", 4, 2,
                "Public camera, radio and television availability without claiming completeness."),
        WORLD_PULSE("WORLD_PULSE", "DU WORLD PULSE", "EVENTS", "WorldPulse", 4, 2,
                "Moving global pulse surface driven by acquired priority events and freshness."),
        ORBIT_WATCH("ORBIT_WATCH", "DU ORBIT WATCH", "SOURCES", "OrbitWatch", 4, 2,
                "Rotating globe state with orbit and acquired-source counters."),
        SOURCE_MATRIX("SOURCE_MATRIX", "DU SOURCE MATRIX", "SOURCES", "SourceMatrix", 4, 2,
                "Changing source-health, age and verification-state matrix."),
        MONITOR_STORIES("MONITOR_STORIES", "DU MONITOR STORIES", "MONITORS", "MonitorStories", 4, 2,
                "Local Monitor story entry surface with report freshness and witness context."),
        COMMAND("COMMAND", "DU COMMAND CENTRE", "BRIEF", "CommandCentre", 4, 4,
                "Responsive globe snapshot, clocks, source health, counts and top signals.");

        public final String key;
        public final String title;
        public final String catalog;
        public final String providerSuffix;
        public final int targetWidth;
        public final int targetHeight;
        public final String description;

        Kind(String key, String title, String catalog, String providerSuffix,
             int targetWidth, int targetHeight, String description) {
            this.key = key;
            this.title = title;
            this.catalog = catalog;
            this.providerSuffix = providerSuffix;
            this.targetWidth = targetWidth;
            this.targetHeight = targetHeight;
            this.description = description;
        }
    }

    private DuWidgetContract() { }

    public static ComponentName component(Context context, Kind kind) {
        return new ComponentName(context.getPackageName(),
                context.getPackageName() + ".DuWidgetProviders$" + kind.providerSuffix);
    }

    public static Kind fromProviderClassName(String className) {
        if (className != null) {
            for (Kind kind : Kind.values()) {
                if (className.endsWith("DuWidgetProviders$" + kind.providerSuffix)) return kind;
            }
        }
        return Kind.COMMAND;
    }
}
