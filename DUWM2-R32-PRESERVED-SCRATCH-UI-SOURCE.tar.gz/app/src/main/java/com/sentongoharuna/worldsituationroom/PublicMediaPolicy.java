package com.sentongoharuna.worldsituationroom;

import java.net.URI;
import java.util.Locale;

/** Shared native safety gate for user and directory supplied media targets. */
public final class PublicMediaPolicy {
    private PublicMediaPolicy() {}

    public static boolean isSafePublicHttpsUrl(String value) {
        return validationError(value).isEmpty();
    }

    public static String validationError(String value) {
        if (value == null || value.trim().isEmpty()) return "HTTPS URL is empty";
        try {
            URI uri = URI.create(value.trim());
            String host = uri.getHost();
            if (!"https".equalsIgnoreCase(uri.getScheme())) {
                return "Only direct HTTPS media is accepted";
            }
            if (host == null || host.trim().isEmpty()) return "The URL has no public host";
            if (uri.getUserInfo() != null) return "Credentials must not be embedded in a URL";
            String lower = host.toLowerCase(Locale.ROOT);
            if (lower.equals("localhost") || lower.endsWith(".localhost")
                    || lower.endsWith(".local") || lower.endsWith(".internal")
                    || lower.endsWith(".home") || lower.contains(":")) {
                return "Local-network and literal-IP media targets are blocked";
            }
            if (lower.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) {
                return "Literal-IP media targets are blocked";
            }
            return "";
        } catch (RuntimeException ignored) {
            return "The media URL is not valid";
        }
    }
}
