package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Transparent on-device correlation and source-health analysis. It never invents records,
 * predicts events, or upgrades a signal's credibility. A correlation only means that two or
 * more distinct publishers produced nearby/similar records inside the stated time window.
 */
public final class SituationAnalyzer {
    private static final long HOUR = 60L * 60L * 1000L;
    private static final String[] REGIONS = {
            "AFRICA", "MIDDLE EAST", "EUROPE", "ASIA", "AMERICAS", "OCEANIA", "GLOBAL"
    };

    public static final class Brief {
        public final int onlineFeeds;
        public final int cachedFeeds;
        public final int offlineFeeds;
        public final int optionalFeeds;
        public final int totalRecords;
        public final int freshRecords;
        public final int prioritySignals;
        public final int rawSignals;
        public final int calculatedSignals;
        public final int reportedSignals;
        public final int officialSignals;
        public final List<DomainWatch> domainWatches;
        public final List<Correlation> correlations;
        public final List<RegionalState> regions;

        Brief(int onlineFeeds, int cachedFeeds, int offlineFeeds, int optionalFeeds,
              int totalRecords, int freshRecords, int prioritySignals, int rawSignals,
              int calculatedSignals, int reportedSignals, int officialSignals,
              List<DomainWatch> domainWatches,
              List<Correlation> correlations, List<RegionalState> regions) {
            this.onlineFeeds = onlineFeeds;
            this.cachedFeeds = cachedFeeds;
            this.offlineFeeds = offlineFeeds;
            this.optionalFeeds = optionalFeeds;
            this.totalRecords = totalRecords;
            this.freshRecords = freshRecords;
            this.prioritySignals = prioritySignals;
            this.rawSignals = rawSignals;
            this.calculatedSignals = calculatedSignals;
            this.reportedSignals = reportedSignals;
            this.officialSignals = officialSignals;
            this.domainWatches = Collections.unmodifiableList(domainWatches);
            this.correlations = Collections.unmodifiableList(correlations);
            this.regions = Collections.unmodifiableList(regions);
        }
    }

    /**
     * A transparent proximity check between one mapped event record and recent physical
     * telemetry. Nearby aircraft or vessels are not evidence that they are connected to the
     * event; the watch only tells an analyst where a manual cross-check may be worthwhile.
     */
    public static final class DomainWatch {
        public final String label;
        public final String explanation;
        public final int aircraftNearby;
        public final int vesselsNearby;
        public final int relatedEvents;
        public final int distinctSources;
        public final int observedDomains;
        public final int severity;
        public final long newestTimestampMs;
        public final Signal anchor;

        DomainWatch(String label, String explanation, int aircraftNearby,
                    int vesselsNearby, int relatedEvents, int distinctSources,
                    int observedDomains, int severity, long newestTimestampMs,
                    Signal anchor) {
            this.label = label;
            this.explanation = explanation;
            this.aircraftNearby = aircraftNearby;
            this.vesselsNearby = vesselsNearby;
            this.relatedEvents = relatedEvents;
            this.distinctSources = distinctSources;
            this.observedDomains = observedDomains;
            this.severity = severity;
            this.newestTimestampMs = newestTimestampMs;
            this.anchor = anchor;
        }
    }

    public static final class Correlation {
        public final String label;
        public final String explanation;
        public final String sources;
        public final long newestTimestampMs;
        public final int severity;
        public final Signal primary;
        public final int recordCount;

        Correlation(String label, String explanation, String sources,
                    long newestTimestampMs, int severity, Signal primary, int recordCount) {
            this.label = label;
            this.explanation = explanation;
            this.sources = sources;
            this.newestTimestampMs = newestTimestampMs;
            this.severity = severity;
            this.primary = primary;
            this.recordCount = recordCount;
        }
    }

    public static final class RegionalState {
        public final String region;
        public final int observedScore;
        public final int recordCount;
        public final int priorityCount;
        public final int recent12hCount;
        public final int previous12hCount;
        public final String level;

        RegionalState(String region, int observedScore, int recordCount,
                      int priorityCount, int recent12hCount, int previous12hCount,
                      String level) {
            this.region = region;
            this.observedScore = observedScore;
            this.recordCount = recordCount;
            this.priorityCount = priorityCount;
            this.recent12hCount = recent12hCount;
            this.previous12hCount = previous12hCount;
            this.level = level;
        }

        public int twelveHourMovement() {
            return recent12hCount - previous12hCount;
        }
    }

    private SituationAnalyzer() {}

    public static Brief analyze(Map<Signal.Layer, List<Signal>> layers,
                                Map<Signal.Layer, FeedStatus> statuses,
                                long nowMs) {
        int online = 0;
        int cached = 0;
        int offline = 0;
        int optional = 0;
        for (FeedStatus status : statuses.values()) {
            if (status == null) continue;
            switch (status.state) {
                case LIVE:
                case READY:
                    online++;
                    break;
                case DELAYED:
                case CACHED:
                    cached++;
                    break;
                case OFFLINE:
                    offline++;
                    break;
                case KEY_REQUIRED:
                    optional++;
                    break;
                default:
                    break;
            }
        }

        int total = 0;
        int fresh = 0;
        int priority = 0;
        int raw = 0;
        int calculated = 0;
        int reported = 0;
        int official = 0;
        for (Map.Entry<Signal.Layer, List<Signal>> entry : layers.entrySet()) {
            List<Signal> values = entry.getValue();
            if (values == null) continue;
            total += values.size();
            long freshWindow = freshnessWindow(entry.getKey());
            for (Signal signal : values) {
                if (signal.timestampMs > 0L && nowMs - signal.timestampMs <= freshWindow) fresh++;
                if (signal.severity >= 4 && isEventLayer(signal.layer)) priority++;
                if (signal.credibility == Signal.Credibility.RAW_SIGNAL) raw++;
                if (signal.credibility == Signal.Credibility.CALCULATED) calculated++;
                if (signal.credibility == Signal.Credibility.REPORTED) reported++;
                if (signal.credibility == Signal.Credibility.CONFIRMED) official++;
            }
        }

        List<Signal> eventSignals = new ArrayList<>();
        addRecent(eventSignals, layers.get(Signal.Layer.NEWS), nowMs, 24L * HOUR);
        addRecent(eventSignals, layers.get(Signal.Layer.NATURAL), nowMs, 72L * HOUR);
        List<DomainWatch> domainWatches = crossDomainWatches(layers, eventSignals, nowMs);
        List<Correlation> correlations = correlate(eventSignals);
        List<RegionalState> regions = regionalStates(eventSignals, nowMs);
        return new Brief(online, cached, offline, optional, total, fresh, priority,
                raw, calculated, reported, official, domainWatches, correlations, regions);
    }

    private static long freshnessWindow(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return 3L * 60L * 1000L;
            case SHIPS: return 5L * 60L * 1000L;
            case WEATHER: return 20L * 60L * 1000L;
            case AIRSPACE: return 20L * 60L * 1000L;
            case SATELLITES: return 3L * HOUR;
            case NEWS: return 6L * HOUR;
            case NATURAL: return 24L * HOUR;
            case SPACE_WEATHER: return 12L * HOUR;
            default: return 24L * HOUR;
        }
    }

    private static boolean isEventLayer(Signal.Layer layer) {
        return layer == Signal.Layer.NEWS || layer == Signal.Layer.NATURAL
                || layer == Signal.Layer.AIRSPACE
                || layer == Signal.Layer.SPACE_WEATHER;
    }

    private static void addRecent(List<Signal> target, List<Signal> source,
                                  long nowMs, long maximumAgeMs) {
        if (source == null) return;
        for (Signal signal : source) {
            long age = Math.max(0L, nowMs - signal.timestampMs);
            if (age <= maximumAgeMs) target.add(signal);
        }
    }

    private static List<Correlation> correlate(List<Signal> signals) {
        List<Signal> ordered = new ArrayList<>(signals);
        Collections.sort(ordered,
                (first, second) -> Long.compare(second.timestampMs, first.timestampMs));
        List<Correlation> result = new ArrayList<>();
        Set<String> consumed = new HashSet<>();
        for (Signal seed : ordered) {
            if (consumed.contains(seed.id)) continue;
            List<Signal> cluster = new ArrayList<>();
            cluster.add(seed);
            LinkedHashSet<String> sources = new LinkedHashSet<>();
            sources.add(normalizedSource(seed.source));
            for (Signal candidate : ordered) {
                if (candidate == seed || consumed.contains(candidate.id)) continue;
                if (Math.abs(seed.timestampMs - candidate.timestampMs) > 12L * HOUR) continue;
                boolean nearby = seed.hasLocation() && candidate.hasLocation()
                        && SatelliteMapView.distanceKm(seed.latitude, seed.longitude,
                        candidate.latitude, candidate.longitude) <= 300d;
                boolean similar = titleSimilarity(seed.title, candidate.title) >= 0.42d;
                boolean compatible = seed.eventType.equals(candidate.eventType)
                        || similar;
                if (compatible && (nearby || similar)) {
                    cluster.add(candidate);
                    sources.add(normalizedSource(candidate.source));
                }
            }
            if (sources.size() < 2) continue;
            Collections.sort(cluster,
                    (first, second) -> Long.compare(second.timestampMs, first.timestampMs));
            int severity = 1;
            for (Signal item : cluster) severity = Math.max(severity, item.severity);
            String label = seed.eventType + " / " + seed.region + " / "
                    + shortText(cluster.get(0).title, 74);
            String explanation = cluster.size() + " source-attributed records align within "
                    + "12 hours by geography or headline language. Correlation is not confirmation.";
            result.add(new Correlation(label, explanation, joinSources(sources),
                    cluster.get(0).timestampMs, severity, cluster.get(0), cluster.size()));
            for (Signal item : cluster) consumed.add(item.id);
            if (result.size() >= 12) break;
        }
        Collections.sort(result, (first, second) -> Long.compare(second.newestTimestampMs,
                first.newestTimestampMs));
        return result;
    }

    private static List<DomainWatch> crossDomainWatches(
            Map<Signal.Layer, List<Signal>> layers,
            List<Signal> eventSignals,
            long nowMs) {
        List<Signal> anchors = new ArrayList<>();
        for (Signal signal : eventSignals) {
            if (signal.hasLocation()) anchors.add(signal);
        }
        Collections.sort(anchors, (first, second) -> {
            int severity = Integer.compare(second.severity, first.severity);
            return severity != 0 ? severity
                    : Long.compare(second.timestampMs, first.timestampMs);
        });

        List<Signal> flights = layers.get(Signal.Layer.FLIGHTS);
        List<Signal> vessels = layers.get(Signal.Layer.SHIPS);
        if (flights == null) flights = Collections.emptyList();
        if (vessels == null) vessels = Collections.emptyList();
        List<DomainWatch> result = new ArrayList<>();
        List<Signal> acceptedAnchors = new ArrayList<>();

        for (Signal anchor : anchors) {
            if (result.size() >= 12 || acceptedAnchors.size() >= 24) break;
            boolean duplicateArea = false;
            for (Signal accepted : acceptedAnchors) {
                if (SatelliteMapView.distanceKm(anchor.latitude, anchor.longitude,
                        accepted.latitude, accepted.longitude) <= 220d) {
                    duplicateArea = true;
                    break;
                }
            }
            if (duplicateArea) continue;
            acceptedAnchors.add(anchor);

            int nearbyAircraft = countRecentNearby(
                    flights, anchor.latitude, anchor.longitude, 500d, nowMs, 20L * 60L * 1000L);
            int nearbyVessels = countRecentNearby(
                    vessels, anchor.latitude, anchor.longitude, 300d, nowMs, 45L * 60L * 1000L);
            int relatedEvents = 0;
            LinkedHashSet<String> sources = new LinkedHashSet<>();
            long newest = anchor.timestampMs;
            for (Signal candidate : eventSignals) {
                if (!candidate.hasLocation()) continue;
                if (Math.abs(anchor.timestampMs - candidate.timestampMs) > 12L * HOUR) continue;
                if (SatelliteMapView.distanceKm(anchor.latitude, anchor.longitude,
                        candidate.latitude, candidate.longitude) > 300d) continue;
                relatedEvents++;
                sources.add(normalizedSource(candidate.source));
                newest = Math.max(newest, candidate.timestampMs);
            }
            int domains = 1 + (nearbyAircraft > 0 ? 1 : 0) + (nearbyVessels > 0 ? 1 : 0);
            if (domains < 2) continue;

            String label = anchor.eventType + " / " + anchor.region + " / "
                    + shortText(anchor.title, 68);
            String explanation = String.format(Locale.US,
                    "Observed near the mapped event coordinate: %,d aircraft fixes within "
                            + "500 km (20-minute window), %,d vessel fixes within 300 km "
                            + "(45-minute window), and %,d event records from %,d publishers "
                            + "within 300 km/12 hours. Proximity does not prove connection.",
                    nearbyAircraft, nearbyVessels, relatedEvents, sources.size());
            result.add(new DomainWatch(label, explanation, nearbyAircraft, nearbyVessels,
                    relatedEvents, sources.size(), domains, anchor.severity, newest, anchor));
        }
        Collections.sort(result, (first, second) -> {
            int domains = Integer.compare(second.observedDomains, first.observedDomains);
            if (domains != 0) return domains;
            int severity = Integer.compare(second.severity, first.severity);
            return severity != 0 ? severity
                    : Long.compare(second.newestTimestampMs, first.newestTimestampMs);
        });
        return result;
    }

    private static int countRecentNearby(
            List<Signal> signals,
            double latitude,
            double longitude,
            double radiusKm,
            long nowMs,
            long maximumAgeMs) {
        int count = 0;
        for (Signal signal : signals) {
            if (!signal.hasLocation() || signal.timestampMs <= 0L) continue;
            long age = Math.max(0L, nowMs - signal.timestampMs);
            if (age > maximumAgeMs) continue;
            if (SatelliteMapView.distanceKm(latitude, longitude,
                    signal.latitude, signal.longitude) <= radiusKm) count++;
        }
        return count;
    }

    private static List<RegionalState> regionalStates(List<Signal> signals, long nowMs) {
        EnumMap<RegionKey, MutableRegion> working = new EnumMap<>(RegionKey.class);
        for (RegionKey key : RegionKey.values()) working.put(key, new MutableRegion(key.label));
        for (Signal signal : signals) {
            RegionKey key = RegionKey.from(signal.region);
            MutableRegion region = working.get(key);
            region.count++;
            if (signal.severity >= 4) region.priority++;
            long window = signal.layer == Signal.Layer.NATURAL ? 72L * HOUR : 24L * HOUR;
            double age = Math.max(0L, nowMs - signal.timestampMs);
            if (age <= 12L * HOUR) region.recent12h++;
            else if (age <= 24L * HOUR) region.previous12h++;
            double decay = Math.max(0.12d, 1d - age / window);
            double credibility = signal.credibility == Signal.Credibility.CONFIRMED ? 1d
                    : signal.credibility == Signal.Credibility.REPORTED ? 0.78d : 0.48d;
            region.weight += signal.severity * decay * credibility;
        }
        List<RegionalState> result = new ArrayList<>();
        for (String label : REGIONS) {
            MutableRegion region = working.get(RegionKey.from(label));
            int score = Math.min(99, (int) Math.round(region.weight * 3.6d));
            String level = score >= 55 ? "HIGH OBSERVED DENSITY"
                    : score >= 30 ? "ELEVATED"
                    : score >= 12 ? "WATCH" : "BASELINE";
            result.add(new RegionalState(label, score, region.count, region.priority,
                    region.recent12h, region.previous12h, level));
        }
        Collections.sort(result, (first, second) -> {
            int score = Integer.compare(second.observedScore, first.observedScore);
            return score != 0 ? score : first.region.compareTo(second.region);
        });
        return result;
    }

    private static double titleSimilarity(String first, String second) {
        Set<String> a = words(first);
        Set<String> b = words(second);
        if (a.isEmpty() || b.isEmpty()) return 0d;
        Set<String> intersection = new HashSet<>(a);
        intersection.retainAll(b);
        Set<String> union = new HashSet<>(a);
        union.addAll(b);
        return intersection.size() / (double) union.size();
    }

    private static Set<String> words(String value) {
        Set<String> result = new HashSet<>();
        String clean = value == null ? "" : value.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9 ]", " ");
        for (String word : clean.split("\\s+")) {
            if (word.length() >= 4
                    && !word.matches("this|that|with|from|after|over|says|have|will|live|latest")) {
                result.add(word);
            }
        }
        return result;
    }

    private static String normalizedSource(String value) {
        String clean = value == null ? "Unknown" : value.trim();
        int via = clean.toLowerCase(Locale.ROOT).indexOf(" via ");
        return via > 0 ? clean.substring(0, via).trim() : clean;
    }

    private static String joinSources(LinkedHashSet<String> values) {
        StringBuilder result = new StringBuilder();
        int shown = 0;
        for (String value : values) {
            if (shown >= 4) break;
            if (result.length() > 0) result.append(" • ");
            result.append(value);
            shown++;
        }
        if (values.size() > shown) result.append(" • +").append(values.size() - shown);
        return result.toString();
    }

    private static String shortText(String value, int maximum) {
        String clean = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        return clean.length() <= maximum ? clean
                : clean.substring(0, Math.max(1, maximum - 1)) + "…";
    }

    private enum RegionKey {
        AFRICA("AFRICA"), MIDDLE_EAST("MIDDLE EAST"), EUROPE("EUROPE"), ASIA("ASIA"),
        AMERICAS("AMERICAS"), OCEANIA("OCEANIA"), GLOBAL("GLOBAL");

        final String label;
        RegionKey(String label) { this.label = label; }

        static RegionKey from(String value) {
            String clean = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
            for (RegionKey key : values()) if (key.label.equals(clean)) return key;
            return GLOBAL;
        }
    }

    private static final class MutableRegion {
        final String label;
        int count;
        int priority;
        int recent12h;
        int previous12h;
        double weight;
        MutableRegion(String label) { this.label = label; }
    }
}
