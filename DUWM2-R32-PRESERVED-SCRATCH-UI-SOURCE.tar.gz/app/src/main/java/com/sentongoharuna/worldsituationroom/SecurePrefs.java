package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Stores optional provider credentials encrypted by the device Android Keystore. */
public final class SecurePrefs {
    public static final String AIS_KEY = "ais_key";
    public static final String WINDY_KEY = "windy_key";
    public static final String OPENSKY_CLIENT_ID = "opensky_client_id";
    public static final String OPENSKY_CLIENT_SECRET = "opensky_client_secret";
    public static final String COINGECKO_KEY = "coingecko_key";
    public static final String PUBLIC_SAFETY_STREAM = "public_safety_stream";
    public static final String PUBLIC_SAFETY_NAME = "public_safety_name";
    public static final String MONITOR_API_TOKEN = "monitor_api_token";
    public static final String MONITOR_LIVE_TOKEN = "monitor_live_token";

    private static final String STORE = "wsr_secure_preferences";
    private static final String ALIAS = "world_situation_room_provider_keys_v4";
    private final SharedPreferences preferences;

    public SecurePrefs(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }

    public synchronized void put(String name, String value) {
        String clean = value == null ? "" : value.trim();
        if (clean.isEmpty()) {
            preferences.edit().remove(name).apply();
            return;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] encrypted = cipher.doFinal(clean.getBytes(StandardCharsets.UTF_8));
            String packed = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP)
                    + "." + Base64.encodeToString(encrypted, Base64.NO_WRAP);
            preferences.edit().putString(name, packed).apply();
        } catch (Exception error) {
            throw new IllegalStateException("Unable to protect provider credential", error);
        }
    }

    public synchronized String get(String name) {
        String packed = SafePreferences.string(preferences, name, "");
        if (packed == null || packed.isEmpty()) {
            return "";
        }
        try {
            String[] parts = packed.split("\\.", 2);
            if (parts.length != 2) {
                return "";
            }
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] encrypted = Base64.decode(parts[1], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception error) {
            preferences.edit().remove(name).apply();
            return "";
        }
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(ALIAS)) {
            return (SecretKey) keyStore.getKey(ALIAS, null);
        }
        KeyGenerator generator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }
}
