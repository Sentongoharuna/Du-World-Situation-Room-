package com.sentongoharuna.worldsituationroom;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/**
 * Lightweight on-device propagation of CelesTrak OMM/GP mean elements.
 *
 * <p>This is intentionally labelled as an approximate calculated overlay. It is useful for
 * situational context, but is not SGP4 precision, live telemetry, collision analysis or a
 * safety-of-flight product.</p>
 */
public final class OrbitalPropagator {
    private static final double EARTH_MU_KM3_S2 = 398_600.4418d;
    private static final double EARTH_EQUATORIAL_RADIUS_KM = 6_378.137d;
    private static final double EARTH_ECCENTRICITY_SQUARED = 0.00669437999014d;
    private static final long MAX_ELEMENT_AGE_MS = 14L * 24L * 60L * 60L * 1000L;

    private OrbitalPropagator() { }

    public static final class OrbitalRecord {
        final String catalogId;
        final String objectName;
        final String objectId;
        final String group;
        final String objectType;
        final long epochMs;
        final double meanMotionRevPerDay;
        final double eccentricity;
        final double inclinationDegrees;
        final double ascendingNodeDegrees;
        final double argumentPericenterDegrees;
        final double meanAnomalyDegrees;

        OrbitalRecord(
                String catalogId,
                String objectName,
                String objectId,
                String group,
                String objectType,
                long epochMs,
                double meanMotionRevPerDay,
                double eccentricity,
                double inclinationDegrees,
                double ascendingNodeDegrees,
                double argumentPericenterDegrees,
                double meanAnomalyDegrees) {
            this.catalogId = catalogId;
            this.objectName = objectName;
            this.objectId = objectId;
            this.group = group;
            this.objectType = objectType;
            this.epochMs = epochMs;
            this.meanMotionRevPerDay = meanMotionRevPerDay;
            this.eccentricity = eccentricity;
            this.inclinationDegrees = inclinationDegrees;
            this.ascendingNodeDegrees = ascendingNodeDegrees;
            this.argumentPericenterDegrees = argumentPericenterDegrees;
            this.meanAnomalyDegrees = meanAnomalyDegrees;
        }
    }

    private static final class Position {
        final double latitude;
        final double longitude;
        final double altitudeKm;
        final double speedKmPerSecond;

        Position(double latitude, double longitude, double altitudeKm,
                 double speedKmPerSecond) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.altitudeKm = altitudeKm;
            this.speedKmPerSecond = speedKmPerSecond;
        }
    }

    public static List<OrbitalRecord> parse(String body, String group) throws Exception {
        JSONArray rows = new JSONArray(body);
        List<OrbitalRecord> result = new ArrayList<>();
        for (int index = 0; index < rows.length() && result.size() < 800; index++) {
            JSONObject row = rows.optJSONObject(index);
            if (row == null) continue;
            String catalogId = clean(row.optString("NORAD_CAT_ID", ""));
            double motion = row.optDouble("MEAN_MOTION", Double.NaN);
            double eccentricity = row.optDouble("ECCENTRICITY", Double.NaN);
            double inclination = row.optDouble("INCLINATION", Double.NaN);
            double node = row.optDouble("RA_OF_ASC_NODE", Double.NaN);
            double pericenter = row.optDouble("ARG_OF_PERICENTER", Double.NaN);
            double anomaly = row.optDouble("MEAN_ANOMALY", Double.NaN);
            long epoch = parseEpoch(row.optString("EPOCH", ""));
            if (catalogId.isEmpty() || epoch <= 0L || !finite(motion)
                    || !finite(eccentricity) || !finite(inclination)
                    || !finite(node) || !finite(pericenter) || !finite(anomaly)
                    || motion <= 0d || eccentricity < 0d || eccentricity >= 1d) {
                continue;
            }
            result.add(new OrbitalRecord(
                    catalogId,
                    clean(row.optString("OBJECT_NAME", "OBJECT " + catalogId)),
                    clean(row.optString("OBJECT_ID", "NOT REPORTED")),
                    group == null ? "OPERATIONAL" : group.trim().toUpperCase(Locale.ROOT),
                    clean(row.optString("OBJECT_TYPE", "PAYLOAD")),
                    epoch, motion, eccentricity, inclination, node, pericenter, anomaly));
        }
        return result;
    }

    public static List<Signal> signals(List<OrbitalRecord> records, long calculationTimeMs) {
        List<Signal> result = new ArrayList<>();
        if (records == null) return result;
        SimpleDateFormat utc = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US);
        utc.setTimeZone(TimeZone.getTimeZone("UTC"));
        for (OrbitalRecord record : records) {
            long elementAge = Math.max(0L, calculationTimeMs - record.epochMs);
            if (elementAge > MAX_ELEMENT_AGE_MS) continue;
            Position position = propagate(record, calculationTimeMs);
            Position ahead = propagate(record, calculationTimeMs + 10_000L);
            if (position == null || ahead == null) continue;
            double heading = bearing(position.latitude, position.longitude,
                    ahead.latitude, ahead.longitude);
            double periodMinutes = 1_440d / record.meanMotionRevPerDay;
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("POSITION BASIS", "Approximate on-device propagation from public GP elements");
            facts.put("TELEMETRY", "Not live telemetry • not for navigation or safety decisions");
            facts.put("NORAD CATALOG", record.catalogId);
            facts.put("OBJECT ID", record.objectId.isEmpty() ? "Not reported" : record.objectId);
            facts.put("OBJECT TYPE", record.objectType.isEmpty() ? "Not reported" : record.objectType);
            facts.put("CELESTRAK GROUP", record.group);
            facts.put("ELEMENT EPOCH", utc.format(new Date(record.epochMs)));
            facts.put("ELEMENT AGE", ageLabel(elementAge));
            facts.put("CALCULATED AT", utc.format(new Date(calculationTimeMs)));
            facts.put("ALTITUDE ESTIMATE", String.format(Locale.US, "%,.0f km", position.altitudeKm));
            facts.put("ORBITAL SPEED ESTIMATE", String.format(Locale.US, "%.2f km/s", position.speedKmPerSecond));
            facts.put("ORBIT PERIOD", String.format(Locale.US, "%.1f min", periodMinutes));
            facts.put("INCLINATION", String.format(Locale.US, "%.2f°", record.inclinationDegrees));
            facts.put("MODEL", "Keplerian OMM preview; SGP4 precision is not claimed");
            result.add(new Signal(
                    "orbit-" + record.catalogId,
                    Signal.Layer.SATELLITES,
                    record.objectName.isEmpty() ? "ORBITAL OBJECT " + record.catalogId
                            : record.objectName,
                    "Calculated public-orbit position. This overlay is contextual and must "
                            + "not be read as an observation, tasking record or proof of activity.",
                    position.latitude, position.longitude, heading,
                    position.speedKmPerSecond * 1_000d,
                    calculationTimeMs,
                    "CelesTrak GP",
                    "https://celestrak.org/NORAD/elements/",
                    Signal.Credibility.CALCULATED,
                    "ORBITAL", regionFor(position.latitude, position.longitude), 1, facts));
        }
        return result;
    }

    /** De-duplicates groups while retaining the freshest element set for each catalog id. */
    public static List<OrbitalRecord> merge(List<List<OrbitalRecord>> groups) {
        LinkedHashMap<String, OrbitalRecord> records = new LinkedHashMap<>();
        if (groups != null) {
            for (List<OrbitalRecord> group : groups) {
                if (group == null) continue;
                for (OrbitalRecord record : group) {
                    OrbitalRecord previous = records.get(record.catalogId);
                    if (previous == null || record.epochMs > previous.epochMs) {
                        records.put(record.catalogId, record);
                    }
                }
            }
        }
        return new ArrayList<>(records.values());
    }

    private static Position propagate(OrbitalRecord record, long timeMs) {
        try {
            double meanMotion = record.meanMotionRevPerDay * 2d * Math.PI / 86_400d;
            double semiMajor = Math.cbrt(EARTH_MU_KM3_S2 / (meanMotion * meanMotion));
            double elapsedSeconds = (timeMs - record.epochMs) / 1_000d;
            double meanAnomaly = normalRadians(Math.toRadians(record.meanAnomalyDegrees)
                    + meanMotion * elapsedSeconds);
            double eccentricAnomaly = meanAnomaly;
            for (int iteration = 0; iteration < 10; iteration++) {
                eccentricAnomaly -= (eccentricAnomaly
                        - record.eccentricity * Math.sin(eccentricAnomaly) - meanAnomaly)
                        / (1d - record.eccentricity * Math.cos(eccentricAnomaly));
            }
            double trueAnomaly = Math.atan2(
                    Math.sqrt(1d - record.eccentricity * record.eccentricity)
                            * Math.sin(eccentricAnomaly),
                    Math.cos(eccentricAnomaly) - record.eccentricity);
            double radius = semiMajor
                    * (1d - record.eccentricity * Math.cos(eccentricAnomaly));
            double inclination = Math.toRadians(record.inclinationDegrees);
            double node = Math.toRadians(record.ascendingNodeDegrees);
            double argument = Math.toRadians(record.argumentPericenterDegrees) + trueAnomaly;

            double xEci = radius * (Math.cos(node) * Math.cos(argument)
                    - Math.sin(node) * Math.sin(argument) * Math.cos(inclination));
            double yEci = radius * (Math.sin(node) * Math.cos(argument)
                    + Math.cos(node) * Math.sin(argument) * Math.cos(inclination));
            double zEci = radius * Math.sin(argument) * Math.sin(inclination);

            double sidereal = greenwichSiderealRadians(timeMs);
            double x = Math.cos(sidereal) * xEci + Math.sin(sidereal) * yEci;
            double y = -Math.sin(sidereal) * xEci + Math.cos(sidereal) * yEci;
            double z = zEci;
            double longitude = wrapLongitude(Math.toDegrees(Math.atan2(y, x)));
            double horizontal = Math.sqrt(x * x + y * y);
            double latitude = Math.atan2(z,
                    horizontal * (1d - EARTH_ECCENTRICITY_SQUARED));
            double altitude = 0d;
            for (int iteration = 0; iteration < 6; iteration++) {
                double sin = Math.sin(latitude);
                double normal = EARTH_EQUATORIAL_RADIUS_KM
                        / Math.sqrt(1d - EARTH_ECCENTRICITY_SQUARED * sin * sin);
                altitude = horizontal / Math.max(0.000001d, Math.cos(latitude)) - normal;
                latitude = Math.atan2(z,
                        horizontal * (1d - EARTH_ECCENTRICITY_SQUARED
                                * normal / (normal + altitude)));
            }
            double speed = Math.sqrt(EARTH_MU_KM3_S2
                    * Math.max(0d, 2d / radius - 1d / semiMajor));
            double latitudeDegrees = Math.toDegrees(latitude);
            if (!finite(latitudeDegrees) || !finite(longitude) || !finite(altitude)
                    || latitudeDegrees < -90d || latitudeDegrees > 90d) return null;
            return new Position(latitudeDegrees, longitude, altitude, speed);
        } catch (RuntimeException error) {
            return null;
        }
    }

    private static double greenwichSiderealRadians(long timeMs) {
        double julian = timeMs / 86_400_000d + 2_440_587.5d;
        double centuries = (julian - 2_451_545d) / 36_525d;
        double degrees = 280.46061837d
                + 360.98564736629d * (julian - 2_451_545d)
                + 0.000387933d * centuries * centuries
                - centuries * centuries * centuries / 38_710_000d;
        return Math.toRadians(((degrees % 360d) + 360d) % 360d);
    }

    private static double bearing(double firstLat, double firstLon,
                                  double secondLat, double secondLon) {
        double first = Math.toRadians(firstLat);
        double second = Math.toRadians(secondLat);
        double delta = Math.toRadians(wrapLongitude(secondLon - firstLon));
        double y = Math.sin(delta) * Math.cos(second);
        double x = Math.cos(first) * Math.sin(second)
                - Math.sin(first) * Math.cos(second) * Math.cos(delta);
        return (Math.toDegrees(Math.atan2(y, x)) + 360d) % 360d;
    }

    private static long parseEpoch(String value) {
        String text = value == null ? "" : value.trim();
        if (text.isEmpty()) return 0L;
        int dot = text.indexOf('.');
        if (dot > 0) {
            int zone = text.indexOf('Z', dot);
            if (zone < 0) zone = text.length();
            String fraction = text.substring(dot + 1, zone);
            if (fraction.length() > 3) fraction = fraction.substring(0, 3);
            while (fraction.length() < 3) fraction += "0";
            text = text.substring(0, dot + 1) + fraction + text.substring(zone);
        }
        String[] patterns = {
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ss.SSS",
                "yyyy-MM-dd'T'HH:mm:ss"
        };
        for (String pattern : patterns) {
            try {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
                format.setLenient(false);
                format.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date parsed = format.parse(text);
                if (parsed != null) return parsed.getTime();
            } catch (Exception ignored) {
                // Try the next OMM-compatible representation.
            }
        }
        return 0L;
    }

    private static String ageLabel(long ageMs) {
        long minutes = Math.max(0L, ageMs / 60_000L);
        if (minutes < 60L) return minutes + " min";
        long hours = minutes / 60L;
        if (hours < 48L) return hours + " h";
        return hours / 24L + " d";
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }

    private static boolean finite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }

    private static double normalRadians(double value) {
        double result = value % (2d * Math.PI);
        return result < 0d ? result + 2d * Math.PI : result;
    }

    private static double wrapLongitude(double longitude) {
        double value = (longitude + 180d) % 360d;
        if (value < 0d) value += 360d;
        return value - 180d;
    }

    private static String regionFor(double latitude, double longitude) {
        if (latitude < -10d && longitude > 105d) return "OCEANIA";
        if (longitude < -30d) return "AMERICAS";
        if (longitude >= -20d && longitude <= 55d
                && latitude >= -38d && latitude <= 38d) return "AFRICA";
        if (longitude >= -25d && longitude <= 60d && latitude > 38d) return "EUROPE";
        if (longitude >= 25d && longitude <= 65d
                && latitude >= 10d && latitude <= 42d) return "MIDDLE EAST";
        if (longitude > 55d) return "ASIA";
        return "GLOBAL";
    }
}
