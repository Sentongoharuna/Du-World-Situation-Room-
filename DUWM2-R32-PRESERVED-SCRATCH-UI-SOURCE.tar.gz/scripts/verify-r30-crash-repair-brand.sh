#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")/.." && pwd)"
main="$project_dir/app/src/main/java/com/sentongoharuna/worldsituationroom"
manifest="$project_dir/app/src/main/AndroidManifest.xml"
gradle_file="$project_dir/app/build.gradle.kts"
apk="${1:-}"

EXPECTED_VERSION_CODE=33 \
EXPECTED_VERSION_NAME=30.0-2026-crash-repair-brand \
  "$project_dir/scripts/verify-r27-live-motion-widgets.sh" "$apk"

for source in LocalMonitorActivity MonitorReport MonitorStore MonitorProfileStore \
  MonitorApiClient MonitorMediaProvider StoryVideoView MonitorAvatarLoader \
  SafePreferences CrashLedger DuWorldApplication; do
  test -s "$main/$source.java"
done

test -s "$project_dir/R30_RELEASE_NOTES.md"
test -s "$project_dir/LOCAL_MONITORS_API.md"
test -s "$project_dir/app/src/main/res/drawable/du_brand_mark.xml"
test -s "$project_dir/app/src/main/res/drawable/ic_launcher_foreground.xml"
test -s "$project_dir/app/src/main/res/mipmap-anydpi/ic_launcher.xml"
test -s "$project_dir/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml"

grep -Fq 'versionCode = 33' "$gradle_file"
grep -Fq 'versionName = "30.0-2026-crash-repair-brand"' "$gradle_file"
grep -Fq 'android:name=".DuWorldApplication"' "$manifest"
grep -Fq 'android:icon="@mipmap/ic_launcher"' "$manifest"
grep -Fq 'android:roundIcon="@mipmap/ic_launcher"' "$manifest"
grep -Fq '<string name="app_name">DU World Monitor</string>' \
  "$project_dir/app/src/main/res/values/strings.xml"
grep -Fq 'public static final String BRAND = "DU WORLD MONITOR"' "$main/ShareCardData.java"
grep -Fq 'SEE THE WORLD. HEAR THE LOCAL WITNESS.' "$main/ShareCardData.java"

grep -Fq 'CrashLedger.install(this)' "$main/DuWorldApplication.java"
grep -Fq 'shouldUseSafeMode' "$main/MainActivity.java"
grep -Fq 'runUiBoundary' "$main/MainActivity.java"
grep -Fq 'recentCrashMentions' "$main/LocalMonitorActivity.java"
grep -Fq 'SAFE VIDEO MODE' "$main/LocalMonitorActivity.java"
grep -Fq 'isCurrent(MediaPlayer candidate' "$main/StoryVideoView.java"
grep -Fq 'MAX_DECODE_EDGE = 384' "$main/MonitorAvatarLoader.java"
grep -Fq 'LruCache<String, Bitmap>' "$main/MonitorAvatarLoader.java"
grep -Fq 'postToMain' "$main/MonitorApiClient.java"
grep -Fq 'SafePreferences.string(preferences, REPORTS, "[]")' "$main/MonitorStore.java"
grep -Fq 'Every new public report continues to begin as **UNVERIFIED**.' \
  "$project_dir/LOCAL_MONITORS_API.md"

grep -Fq 'MediaStore.ACTION_VIDEO_CAPTURE' "$main/LocalMonitorActivity.java"
grep -Fq 'Intent.ACTION_OPEN_DOCUMENT' "$main/LocalMonitorActivity.java"
grep -Fq 'STATE_DRAFT = "DRAFT"' "$main/MonitorReport.java"
grep -Fq 'STATE_UPLOADING = "UPLOADING"' "$main/MonitorReport.java"
grep -Fq '/v1/uploads/' "$main/MonitorApiClient.java"
grep -Fq 'Upload-Offset' "$main/MonitorApiClient.java"
grep -Fq 'local-monitor:' "$main/MainActivity.java"
grep -Fq 'localMonitorSignals()' "$main/MainActivity.java"

if grep -REn 'android\.webkit\.WebView|<WebView|loadUrl\(' "$project_dir/app/src/main"; then
  echo 'R30 must remain native and cannot embed hosted pages.' >&2
  exit 1
fi

if grep -En '^[[:space:]]*(implementation|api)\(' "$gradle_file"; then
  echo 'R30 introduced a forbidden external Android runtime dependency.' >&2
  exit 1
fi

if test -n "$apk"; then
  sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  build_tools="$(find "$sdk_root/build-tools" -mindepth 1 -maxdepth 1 -type d \
    | sort -V | tail -n 1)"
  badging="$("$build_tools/aapt" dump badging "$apk")"
  grep -Fq "application-label:'DU World Monitor'" <<<"$badging"

  manifest_dump="$("$build_tools/aapt2" dump xmltree "$apk" --file AndroidManifest.xml)"
  grep -Fq 'DuWorldApplication' <<<"$manifest_dump"
  grep -Fq 'LocalMonitorActivity' <<<"$manifest_dump"
  grep -Fq 'MonitorMediaProvider' <<<"$manifest_dump"

  inspect_dir="$(mktemp -d)"
  trap 'test -d "$inspect_dir" && rm -rf -- "$inspect_dir"' EXIT
  unzip -q "$apk" 'classes*.dex' -d "$inspect_dir"
  dex_dump="$({ for dex in "$inspect_dir"/classes*.dex; do "$build_tools/dexdump" -f "$dex"; done; })"
  for component in LocalMonitorActivity MonitorReport MonitorStore MonitorProfileStore \
    MonitorApiClient MonitorMediaProvider StoryVideoView MonitorAvatarLoader \
    SafePreferences CrashLedger DuWorldApplication; do
    grep -Fq "/$component;" <<<"$dex_dump"
  done

  resource_dump="$("$build_tools/aapt" dump resources "$apk")"
  grep -Fq 'du_brand_mark' <<<"$resource_dump"
  grep -Fq 'ic_launcher' <<<"$resource_dump"
fi

echo 'R30 CRASH REPAIR + BRAND PASS: recovery mode + safe media + bounded avatars + adaptive DU globe identity'
