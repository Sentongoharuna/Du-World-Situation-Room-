package com.sentongoharuna.worldsituationroom;

import android.app.Application;

/** Installs local crash-loop protection before any activity or live source starts. */
public final class DuWorldApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        CrashLedger.install(this);
        AppContextHolder.set(this);
        NewsNotifier.channels(this);
    }
}
