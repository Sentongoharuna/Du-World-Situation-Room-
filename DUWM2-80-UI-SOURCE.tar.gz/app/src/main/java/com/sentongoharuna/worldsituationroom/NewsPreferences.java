package com.sentongoharuna.worldsituationroom;
import android.content.*; import java.util.*;
public final class NewsPreferences {
 private final SharedPreferences p; public NewsPreferences(Context c){p=c.getSharedPreferences("du_local_news_r33",Context.MODE_PRIVATE);}
 public boolean source(NewsSource s){return SafePreferences.bool(p,"source_"+s.id,s.enabledByDefault);} public void source(String id,boolean v){p.edit().putBoolean("source_"+id,v).apply();}
 public boolean topic(String t){return SafePreferences.bool(p,"topic_"+t.replace(' ','_'),true);} public void topic(String t,boolean v){p.edit().putBoolean("topic_"+t.replace(' ','_'),v).apply();}
 public boolean images(){return SafePreferences.bool(p,"images",true);} public void images(boolean v){p.edit().putBoolean("images",v).apply();}
 public boolean alerts(){return SafePreferences.bool(p,"alerts",true);} public void alerts(boolean v){p.edit().putBoolean("alerts",v).apply();}
 public boolean breaking(){return SafePreferences.bool(p,"breaking",true);} public void breaking(boolean v){p.edit().putBoolean("breaking",v).apply();}
 public boolean grouped(){return SafePreferences.bool(p,"grouped",true);} public void grouped(boolean v){p.edit().putBoolean("grouped",v).apply();}
 public boolean digest(){return SafePreferences.bool(p,"digest",true);} public void digest(boolean v){p.edit().putBoolean("digest",v).apply();}
 public boolean quiet(){return SafePreferences.bool(p,"quiet",true);} public void quiet(boolean v){p.edit().putBoolean("quiet",v).apply();}
 public void setFlag(String k,boolean v){p.edit().putBoolean(k,v).apply();} public boolean flag(String k,boolean d){return SafePreferences.bool(p,k,d);} public long time(String k,long d){return SafePreferences.longValue(p,k,d);} public void setTime(String k,long v){p.edit().putLong(k,v).apply();}
 public String feed(String id){return SafePreferences.string(p,"feed_"+id,"");} public long feedAt(String id){return SafePreferences.longValue(p,"feed_at_"+id,0);} public void feed(String id,String u){p.edit().putString("feed_"+id,u).putLong("feed_at_"+id,System.currentTimeMillis()).apply();}
 public long retryAt(String id){return SafePreferences.longValue(p,"retry_at_"+id,0);} public void retryAt(String id,long v){p.edit().putLong("retry_at_"+id,v).apply();}
 public void status(String id,String v){p.edit().putString("status_"+id,v).apply();} public String status(String id){return SafePreferences.string(p,"status_"+id,"Checking");}
}
