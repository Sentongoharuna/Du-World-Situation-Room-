package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.content.*;
public final class NewsWidgetLinks{private NewsWidgetLinks(){}public static PendingIntent story(Context c,String id,int request){Intent i=new Intent(c,LocalNewsActivity.class).putExtra("story_id",id).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);return PendingIntent.getActivity(c,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}}
