package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class NewsSignalBridge{
 private NewsSignalBridge(){}
 public static List<Signal> signals(Context c,int limit){ArrayList<Signal>r=new ArrayList<>();try{for(NewsItem n:new NewsStore(c).load()){GeoIndex.Point p=GeoIndex.find(n.title+" "+n.summary);if(p==null)continue;Map<String,String>f=new LinkedHashMap<>();f.put("STORY_ID",n.id);f.put("TOPIC",n.topic);f.put("OUTLET",n.sourceName);r.add(new Signal("localnews:"+n.id,Signal.Layer.NEWS,n.title,n.summary,p.latitude,p.longitude,Double.NaN,n.publishedAt,n.sourceName,n.link,Signal.Credibility.REPORTED,n.isBreaking?"BREAKING":"NEWS",n.region,n.isBreaking?5:2,f));if(r.size()>=limit)break;}}catch(RuntimeException e){CrashLedger.recordRecovered(c,"NewsSignalBridge",e);}return r;}
 public static List<NewsItem> brief(Context c){ArrayList<NewsItem>b=new ArrayList<>();for(NewsItem n:new NewsStore(c).topUganda(20))if(n.isBreaking)b.add(n);for(NewsItem n:new NewsStore(c).topUganda(20))if(!b.contains(n))b.add(n);return b.subList(0,Math.min(3,b.size()));}
}