package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class NewsActionReceiver extends BroadcastReceiver {
 public static final String MARK_READ="com.sentongoharuna.worldsituationroom.NEWS_MARK_READ";
 @Override public void onReceive(Context c,Intent i){try{if(MARK_READ.equals(i.getAction())){String id=i.getStringExtra("story_id");if(id!=null)new NewsStore(c).markRead(id);DuWidgetUpdater.requestUpdate(c);}}catch(RuntimeException e){CrashLedger.recordRecovered(c,"NewsActionReceiver",e);}}
}