# DUWM2 — 80% PRODUCT TARGET

VISUAL MASTER
The approved DU WORLD MONITOR Live Source Index / Airspace interface is the master UI:
near-black operations background, thin blue-grey outlines, compact telemetry, green live/source states,
cyan navigation, amber operational emphasis, red breaking/critical only, compact rounded cards.

FIVE PRIMARY PAGES
HOME = full situation dashboard, no blank lower half.
NEWS = full visual news operations, never a different-looking app.
MAP = globe/geographic operations only.
MONITORS = full local monitor product, never automatic globe fallback.
MORE = professional grouped systems console, never generic grey Android button wall.

CARD CONTRACT
Every major card should contain, when meaningful:
1 visual/thumbnail/status box; headline/system; live/source state; concise explanation;
source/freshness/location telemetry; DETAIL; contextual action; SHARE CARD.
Never invent an unrelated picture when no real visual exists.

DETAIL CONTRACT
Every specialist function must have a detail gateway before the old operational engine:
visual/preview, WHAT HAPPENED, WHERE, WHEN, SOURCES, RELATED INTELLIGENCE,
explicit OPEN OPERATIONAL VIEW, SHARE CARD.
A touch must not silently dump the user on the globe.

PAGE-FILL CONTRACT
Sparse live data is filled with honest cached state, source health, last refresh, filters,
related intelligence, watchlist/offline state, and explanatory empty state — never fake data.

NAVIGATION CONTRACT
HOME/NEWS/MAP/MONITORS/MORE have one location/order/style.
MAP alone owns the primary globe route.
Every specialist touch has a declared destination.

SHARE CONTRACT
Professional DEVELOP.UGANDA share output must carry title/system, state, source attribution,
location/time when available, and original publisher/link where applicable.

ENGINE FREEZE
Do not casually rewrite working R33 aggregation, notifications, widgets, wallpaper, GeoIndex,
NewsStore, watchlists, or globe engine while improving DUWM2 presentation.
