DEVELOP.UGANDA WORLD MONITOR — UPGRADE9
Uganda Situation: existing GeoIndex/NEWS signals remain authoritative; no invented coordinates.
Event Rooms: clustered developing stories become one event with report count and breaking state.
Briefing: existing six-hour source-attributed brief preserved.
Watchlists: persistent followed place/company/topic terms and matching saved news.
Local Monitors: existing monitor network remains separate from professional outlet attribution.
Evidence: source count, official-source indicator, developing status; never a truth score.
Wallpaper 2.0: Minimal/Globe/Intelligence, motion, speed, OLED, clock, cached headline, no wallpaper networking.
Command Center: dedicated full-screen cached live counters and offline intelligence state.
Share: existing DEVELOP.UGANDA publisher-attributed share foundation preserved.
Offline Pack: saved stories, map signals, watchlists available without network.
Diagnostics: story/signal/watchlist counts, refresh time, notification state.
Safety: additive native Java/Views; no WebView, OkHttp, WorkManager or runtime library.
