#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"; J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
A="$J/LocalNewsActivity.java"; N="$J/NewsPreferences.java"; G="$J/NewsAggregator.java"; R="$J/RssParser.java"
grep -F 'String[] groups={"Main news","TV & radio","Luganda","Business","Sports","Entertainment","Tech","Government","East Africa","World"}' "$A"
grep -F 'FOLLOW TOPICS' "$A"
grep -F 'Morning digest' "$A"; grep -F 'Quiet hours' "$A"; grep -F 'Grouped alerts' "$A"
grep -F 'public void alerts(boolean v)' "$N"; grep -F 'public void digest(boolean v)' "$N"; grep -F 'public void quiet(boolean v)' "$N"
grep -F '(dataSaver()||!prefs.images())?"" : i.imageUrl' "$G"
grep -F 'EEE, dd MMM yy HH:mm:ss Z' "$R"; grep -F "yyyy-MM-dd'T'HH:mm:ss.SSSXXX" "$R"
grep -F 'f.setTimeZone(TimeZone.getTimeZone("UTC"))' "$R"
echo "R33 SETTINGS + DATE COMPLETION: PASS"
