#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuEventRooms.java DuWatchlists.java DuEvidence.java DuOfflinePack.java DuDiagnosticsActivity.java DuCommandCenterActivity.java DuIntelligenceHubActivity.java;do test -s "$J/$f";done
grep -F 'clusterId' "$J/DuEventRooms.java" >/dev/null
grep -F 'du_watchlists' "$J/DuWatchlists.java" >/dev/null
grep -F 'OFFICIAL SOURCE' "$J/DuEvidence.java" >/dev/null
grep -F 'COMMAND CENTER' "$J/DuCommandCenterActivity.java" >/dev/null
! grep -F 'areNotificationsEnabled()' "$J/DuDiagnosticsActivity.java"
for api in 'computeIfAbsent(' 'getOrDefault(' 'putIfAbsent(' 'removeIf(' 'replaceAll('; do
  ! grep -R -F "$api" "$J"/Du*.java
done
! grep -F 'new SafePreferences(' "$J/DuDiagnosticsActivity.java"
grep -F 'OLED deep black' "$J/DuWallpaperSettingsActivity.java" >/dev/null
grep -F 'SafePreferences.longValue' "$J/DuDiagnosticsActivity.java" >/dev/null
! grep -R -F 'new SafePreferences(' "$J"/Du*.java
! grep -E 'HttpURLConnection|openConnection|HttpCache' "$J/DuWorldWallpaperService.java"
"$P/scripts/verify-r33-local-news.sh" "$P"
"$P/scripts/verify-r33-safe-logo-upgrade.sh" "$P"
"$P/scripts/verify-r33-upgrade7-ux-wallpaper.sh" "$P"
"$P/scripts/verify-r33-upgrade8-full-ux.sh" "$P"
echo "R33 UPGRADE9 INTELLIGENCE SUITE PASS"
