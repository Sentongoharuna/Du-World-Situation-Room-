#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
test -s "$P/app/src/main/res/drawable/du_safe_mark.xml"
test -s "$P/app/src/main/res/drawable/du_safe_icon_background.xml"
test -s "$P/app/src/main/res/mipmap-anydpi-v26/ic_du_safe_launcher.xml"
test -s "$P/app/src/main/res/mipmap-anydpi-v26/ic_du_safe_launcher_round.xml"
grep -F 'android:icon="@mipmap/ic_du_safe_launcher"' "$P/app/src/main/AndroidManifest.xml" >/dev/null
grep -F 'android:roundIcon="@mipmap/ic_du_safe_launcher_round"' "$P/app/src/main/AndroidManifest.xml" >/dev/null
! grep -R -E '\.(png|jpg|jpeg|webp)' "$P/app/src/main/res/drawable/du_safe_"* >/dev/null 2>&1
echo "R33 SAFE NATIVE DU LOGO PASS"
