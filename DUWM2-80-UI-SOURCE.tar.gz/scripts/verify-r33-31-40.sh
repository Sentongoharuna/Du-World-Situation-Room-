#!/usr/bin/env bash
set -euo pipefail
trap 'echo "R33 31-40 verifier failed at line $LINENO" >&2' ERR
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/NewsSignalBridge.java";grep -F 'new NewsStore(c).load()' "$J/NewsSignalBridge.java"
grep -F 'NEWSSTORE WIRE' "$J/DuWidgetRenderer.java";grep -F 'NewsSignalBridge.brief' "$J/DuWidgetRenderer.java"
grep -F 'topUganda(20)' "$J/NewsSignalBridge.java";grep -F 'GeoIndex.find' "$J/NewsSignalBridge.java";grep -F 'Signal.Layer.NEWS' "$J/NewsSignalBridge.java"
grep -F 'DuWidgetUpdater.updateAll(c)' "$J/NewsAggregator.java"
test -s "$J/NewsWidgetLinks.java";grep -F 'story_id' "$J/NewsWidgetLinks.java";grep -F 'deepLinked' "$J/LocalNewsActivity.java"
grep -F 'scheduleImmediate(context)' "$J/WidgetBootReceiver.java"
grep -F 'CrashLedger.recordRecovered(c,"NewsSource."' "$J/NewsAggregator.java"
grep -F 'detectNetwork().penaltyDeathOnNetwork()' "$J/LocalNewsActivity.java"
echo "R33 31-40 PASS"
