#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuCommandHomeActivity.java DuBrandUi.java DuLiveIntelligenceSafe.java DuSixHourBrief.java DuStoryTimeline.java DuWorldWallpaperService.java DuWallpaperLauncher.java;do test -s "$J/$f";done
grep -F 'HOME","NEWS","MAP","MONITORS","MORE' "$J/DuCommandHomeActivity.java" >/dev/null
grep -F 'du_safe_mark' "$J/DuBrandUi.java" >/dev/null
grep -F 'WallpaperService' "$J/DuWorldWallpaperService.java" >/dev/null
! grep -E 'HttpURLConnection|openConnection|HttpCache' "$J/DuWorldWallpaperService.java"
grep -F 'android.permission.BIND_WALLPAPER' "$M" >/dev/null
test -s "$P/app/src/main/res/xml/du_world_wallpaper.xml"
"$P/scripts/verify-r33-local-news.sh" "$P"
"$P/scripts/verify-r33-safe-logo-upgrade.sh" "$P"
echo "R33 UPGRADE7 ADVANCED UX WALLPAPER PASS"
