#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";R="$J/RssParser.java";T="$J/NewsTopics.java";A="$J/NewsAggregator.java";L="$J/LocalNewsActivity.java"
grep -F 's.length()<=220' "$R";grep -F 'utm_' "$R";grep -F 'fbclid' "$R";grep -F 'getBytes(java.nio.charset.StandardCharsets.UTF_8).length>MAX_FEED_CHARS' "$R"
grep -F 'CRIME & COURTS' "$T";grep -F 'POLITICS' "$T";grep -F 'HEALTH' "$T"
grep -F 'ugSources.size()>=3' "$A";grep -F 'latest-earliest<=60L*60*1000' "$A";grep -F '6L*60*60*1000' "$A"
grep -F 'matchesSearch' "$L";grep -F 'new String[]{"Share","Mark read","Hide this outlet","Follow topic"}' "$L"
grep -F 'a.setOnClickListener(v->versions(n))' "$L";grep -F 'Offline — showing saved news' "$L"
echo "R33 21-30 PASS"
