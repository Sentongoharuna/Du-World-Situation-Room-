#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in NewsSource.java NewsSourceCatalog.java NewsItem.java NewsStore.java NewsAggregator.java NewsNotifier.java LocalNewsActivity.java; do test -s "$J/$f"; done
grep -q POST_NOTIFICATIONS "$P/app/src/main/AndroidManifest.xml"
grep -q 'LocalNewsActivity' "$P/app/src/main/AndroidManifest.xml"
grep -q 'DuWidgetProviders\$LocalNews' "$P/app/src/main/AndroidManifest.xml"
grep -q 'versionCode = 35' "$P/app/build.gradle.kts"
grep -q 'versionName = "33.0-2026-local-news"' "$P/app/build.gradle.kts"
grep -q 'Watchdog Uganda' "$J/NewsSourceCatalog.java"
test "$(grep -c 'NewsSource(' "$J/NewsSourceCatalog.java")" -ge 30
grep -q 'CH_BREAKING' "$J/NewsNotifier.java"; grep -q 'CH_LOCAL' "$J/NewsNotifier.java"; grep -q 'CH_DIGEST' "$J/NewsNotifier.java"
grep -q '"MONITORS"' "$J/MainActivity.java"; grep -q 'LocalNewsActivity.class' "$J/MainActivity.java"
! grep -REn 'android\.webkit\.WebView|<WebView|okhttp3|okio' "$P/app/src/main"
echo 'R33 LOCAL NEWS CONTRACT PASS'

"$P/scripts/verify-r33-first-five.sh" "$P"

"$P/scripts/verify-r33-next-five.sh" "$P"

"$P/scripts/verify-r33-settings-dates.sh" "$P"

"$P/scripts/verify-r33-21-30.sh" "$P"

"$P/scripts/verify-r33-31-40.sh" "$P"
