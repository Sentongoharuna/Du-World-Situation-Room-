#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuRoutes.java DuMoreActivity.java DuNavBar.java DuGlobalSearchActivity.java DuShareCard.java DuWallpaperSettingsActivity.java;do test -s "$J/$f";done
grep -F 'DuCommandHomeActivity' "$M" >/dev/null;grep -F 'android.intent.category.LAUNCHER' "$M" >/dev/null
grep -F 'HOME","NEWS","MAP","MONITORS","MORE' "$J/DuNavBar.java" >/dev/null
grep -F 'REPLAY","FUSE","AIR","SEA","WX' "$J/DuMoreActivity.java" >/dev/null
grep -F 'NewsStore(this).load()' "$J/DuGlobalSearchActivity.java" >/dev/null
grep -F 'NewsSignalBridge.signals' "$J/DuGlobalSearchActivity.java" >/dev/null
grep -F 'DEVELOP.UGANDA WORLD MONITOR' "$J/DuShareCard.java" >/dev/null
grep -F 'MINIMAL","GLOBE","INTELLIGENCE' "$J/DuWallpaperSettingsActivity.java" >/dev/null
grep -F 'SET AS LIVE WALLPAPER' "$J/DuWallpaperSettingsActivity.java" >/dev/null
! grep -E 'HttpURLConnection|openConnection|HttpCache' "$J/DuWorldWallpaperService.java"
"$P/scripts/verify-r33-local-news.sh" "$P"
"$P/scripts/verify-r33-safe-logo-upgrade.sh" "$P"
"$P/scripts/verify-r33-upgrade7-ux-wallpaper.sh" "$P"
echo "R33 UPGRADE8 FULL UX INTEGRATION PASS"
