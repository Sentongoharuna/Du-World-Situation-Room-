# DUWM2 chronological navigation
Universal controls: BACK | GLOBE | CURRENT | NEXT.
Intelligence chain: NEWS -> WIRE -> BRIEF -> RISK -> ANALYST -> FUSION -> EVENTS.
World chain: AIR/AIRSPACE -> SEA -> WX/AIRWX -> ORBIT -> INFRA.
Transport/markets: AIRPORTS -> PORTS -> MARKETS.
Media: RADIO -> TV -> CAM.
Widgets: WIDGETS -> WALLPAPER.
Within any system: Globe -> dedicated page -> source index -> record detail -> source/map/follow/share.
BACK always returns to the actual previous Android screen. GLOBE is always an explicit escape to geographic operations.
NEXT advances only within the logical tool family and is disabled at the end.
