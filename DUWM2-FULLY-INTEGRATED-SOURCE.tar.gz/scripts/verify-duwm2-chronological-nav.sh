#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuChronoNav.java"
grep -F '‹ BACK' "$J/DuChronoNav.java" >/dev/null
grep -F '◉ GLOBE' "$J/DuChronoNav.java" >/dev/null
grep -F 'NEXT ›' "$J/DuChronoNav.java" >/dev/null
grep -F 'case"NEWS":return"WIRE"' "$J/DuChronoNav.java" >/dev/null
grep -F 'case"AIRSPACE":return"SEA"' "$J/DuChronoNav.java" >/dev/null
grep -F 'DuChronoNav.bar' "$J/DuIntelligencePageActivity.java" >/dev/null
grep -F 'DuChronoNav.bar' "$J/DuWorldSystemPageActivity.java" >/dev/null
grep -F 'DuChronoNav.bar' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuChronoNav.bar' "$J/DuMonitorHubActivity.java" >/dev/null
test -s "$P/docs/DUWM2-CHRONOLOGICAL-NAVIGATION.md"
echo "DUWM2 CHRONOLOGICAL NAVIGATION PASS"
