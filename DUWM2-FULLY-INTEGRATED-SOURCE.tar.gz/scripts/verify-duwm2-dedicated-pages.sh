#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuPageRouter.java DuIntelligencePageActivity.java DuWorldSystemPageActivity.java DuTransportMarketPageActivity.java DuMediaPageActivity.java DuSourceHealthPageActivity.java DuWidgetsPageActivity.java DuWallpaperPageActivity.java;do test -s "$J/$f";done
grep -F 'DuIntelligencePageActivity.class' "$J/DuPageRouter.java" >/dev/null
grep -F 'DuWorldSystemPageActivity.class' "$J/DuPageRouter.java" >/dev/null
grep -F 'DuTransportMarketPageActivity.class' "$J/DuPageRouter.java" >/dev/null
grep -F 'DuMediaPageActivity.class' "$J/DuPageRouter.java" >/dev/null
grep -F 'DuPageRouter.open(this,q)' "$J/Du2More.java" >/dev/null
grep -R -F 'LIVE SOURCE INDEX' "$J" >/dev/null
echo "DUWM2 DEDICATED PAGE ROUTING PASS"
