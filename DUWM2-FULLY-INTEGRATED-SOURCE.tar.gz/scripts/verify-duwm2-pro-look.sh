#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuProStrip.java"
test -s "$J/DuMetricRow.java"
grep -F 'setLetterSpacing' "$J/Du2Ui.java" >/dev/null
grep -F 'DuMetricRow.make' "$J/DuGlobeCommandActivity.java" >/dev/null
grep -F 'DuProStrip.make' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuChronoNav.bar' "$J/DuRecordDetailActivity.java" >/dev/null
echo "DUWM2 PRO LOOK PASS"
