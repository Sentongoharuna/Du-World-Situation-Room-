#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuFlow.java DuBreadcrumb.java DuToolRegistry.java;do test -s "$J/$f";done
grep -F 'focus_system' "$J/DuFlow.java" >/dev/null
grep -F 'DuBreadcrumb.make' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuFlow.globe' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuFlow.share' "$J/DuContextBar.java" >/dev/null
grep -F 'DuToolRegistry.purpose' "$J/Du2More.java" >/dev/null
test -s "$P/docs/DUWM2-INTEGRATED-TOOL-CHAIN.md"
echo "DUWM2 INTEGRATED TOOLCHAIN PASS"
