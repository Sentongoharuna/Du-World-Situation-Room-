#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
test "$(grep -o 'android.intent.category.LAUNCHER' "$M" | wc -l)" -eq 1
grep -F 'android:name=".DuIntegratedHomeActivity"' "$M" >/dev/null
for f in DuIntegratedHomeActivity.java DuToolDirectoryActivity.java DuIntegrationStatusActivity.java DuPageRouter.java DuFlow.java DuObjectPayload.java DuVisualEngine.java DuShareRenderer.java DuGlobalSearchActivity.java DuWatchlistActivity.java DuMonitorHubActivity.java DuSituationRoomActivity.java;do test -s "$J/$f";done
grep -F 'ALL TOOLS' "$J/Du2More.java" >/dev/null
grep -F 'INTEGRATION' "$J/Du2More.java" >/dev/null
grep -F 'DuPageRouter.open' "$J/DuToolDirectoryActivity.java" >/dev/null
grep -F 'DuIntelligenceSheet.make' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuSelectionState.set' "$J/DuDeepLinkActivity.java" >/dev/null
grep -R -F 'LIVE SOURCE INDEX' "$J" >/dev/null
grep -R -F 'SHARE THIS PAGE AS CARD' "$J" >/dev/null
echo "DUWM2 FULL INTEGRATION PASS"
