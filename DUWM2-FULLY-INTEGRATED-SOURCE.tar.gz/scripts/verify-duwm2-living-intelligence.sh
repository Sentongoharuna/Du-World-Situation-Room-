#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuLiveModule.java DuShareStudioActivity.java DuSourceFamilyActivity.java;do test -s "$J/$f";done
grep -F 'LIVE INTELLIGENCE MODULES' "$J/DuGlobeCommandActivity.java" >/dev/null
grep -F 'ObjectAnimator' "$J/DuLiveModule.java" >/dev/null
grep -F 'SHARE THIS PAGE AS CARD' "$J/DuSourceFamilyActivity.java" >/dev/null
grep -F 'DuSourceFamilyActivity.class' "$J/Du2More.java" >/dev/null
grep -R -F 'LIVE SOURCE INDEX' "$J" >/dev/null
echo "DUWM2 LIVING INTELLIGENCE PASS"
