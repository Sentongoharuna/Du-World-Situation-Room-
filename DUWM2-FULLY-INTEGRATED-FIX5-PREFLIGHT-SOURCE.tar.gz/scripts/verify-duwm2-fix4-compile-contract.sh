#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
grep -F 'R=Color.rgb(218,70,76)' "$J/Du2Ui.java" >/dev/null
! grep -R -F 'h.postDelayed(tick,60000)' "$J/DuRefreshController.java" >/dev/null
grep -F 'h.postDelayed(this,60000)' "$J/DuRefreshController.java" >/dev/null

# Every Du2Ui constant referenced by generated upgrade code must exist.
for c in BG FG M C G R ALERT; do
  if grep -R -q "Du2Ui\\.$c" "$J"; then
    grep -qE "(^|,)$c=|[, ]$c=" "$J/Du2Ui.java"
  fi
done
echo "DUWM2 FIX4 COMPILE CONTRACT PASS"
